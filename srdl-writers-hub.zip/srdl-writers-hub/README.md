# SRDL Writers Hub

A literacy engagement platform for the Sikhululekile Reading Development and Life Skills (SRDL) programme in Cape Town.

## Tech Stack
- **Vite** + **React** + **TypeScript**
- **Tailwind CSS** + **shadcn/ui**
- **Supabase** (database, auth, realtime)
- **Framer Motion** (animations)

## Getting Started

```sh
# Install dependencies
npm install

# Start dev server
npm run dev
```

## Project Structure

```
src/
  components/
    readingGym/     # Reading Gym session components
    ui/             # shadcn/ui base components
    shared/         # Shared app-wide components
  contexts/         # AuthContext, LearnerContext
  hooks/            # Custom React hooks
  integrations/
    supabase/       # Supabase client, types, constants
  lib/              # Utility functions, readingGym logic, SEO schemas
  pages/            # Page-level route components
  App.tsx           # Root app with routing
```

## Key Features
- Reading Gym live sessions with real-time leaderboard
- Book review submission with word-count earnings (R0.02/word)
- Student & volunteer portals
- Admin dashboard
- Story creation and feeds
- SEO-optimised review and story pages
