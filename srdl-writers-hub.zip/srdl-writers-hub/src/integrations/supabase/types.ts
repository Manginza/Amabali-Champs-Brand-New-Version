export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]


export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      book_reviews: {
        Row: {
          avg_external_rating: number | null
          book_name: string
          created_at: string
          external_rating_count: number | null
          grade: string
          id: string
          is_registered_user: boolean
          language: string | null
          review_content: string
          review_title: string
          reward_status: string | null
          school_id: string
          session_id: string | null
          star_rating: number
          student_name: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          avg_external_rating?: number | null
          book_name: string
          created_at?: string
          external_rating_count?: number | null
          grade: string
          id?: string
          is_registered_user?: boolean
          language?: string | null
          review_content: string
          review_title: string
          reward_status?: string | null
          school_id: string
          session_id?: string | null
          star_rating: number
          student_name: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          avg_external_rating?: number | null
          book_name?: string
          created_at?: string
          external_rating_count?: number | null
          grade?: string
          id?: string
          is_registered_user?: boolean
          language?: string | null
          review_content?: string
          review_title?: string
          reward_status?: string | null
          school_id?: string
          session_id?: string | null
          star_rating?: number
          student_name?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      external_ratings: {
        Row: {
          created_at: string
          id: string
          rating: number
          session_id: string | null
          target_id: string
          target_type: string
        }
        Insert: {
          created_at?: string
          id?: string
          rating: number
          session_id?: string | null
          target_id: string
          target_type: string
        }
        Update: {
          created_at?: string
          id?: string
          rating?: number
          session_id?: string | null
          target_id?: string
          target_type?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          balance: number
          bio: string | null
          company_name: string | null
          created_at: string
          email: string
          full_name: string
          grade: string | null
          id: string
          job_title: string | null
          phone_number: string | null
          school_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          bio?: string | null
          company_name?: string | null
          created_at?: string
          email: string
          full_name: string
          grade?: string | null
          id?: string
          job_title?: string | null
          phone_number?: string | null
          school_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          bio?: string | null
          company_name?: string | null
          created_at?: string
          email?: string
          full_name?: string
          grade?: string | null
          id?: string
          job_title?: string | null
          phone_number?: string | null
          school_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      reading_gym_reviews: {
        Row: {
          avatar_emoji: string | null
          book_author: string | null
          book_title: string
          earnings_cents: number
          id: string
          is_approved: boolean | null
          learner_id: string
          learner_name: string
          review_text: string
          session_id: string
          star_rating: number | null
          submitted_at: string | null
          word_count: number
        }
        Insert: {
          avatar_emoji?: string | null
          book_author?: string | null
          book_title: string
          earnings_cents: number
          id?: string
          is_approved?: boolean | null
          learner_id: string
          learner_name: string
          review_text: string
          session_id: string
          star_rating?: number | null
          submitted_at?: string | null
          word_count: number
        }
        Update: {
          avatar_emoji?: string | null
          book_author?: string | null
          book_title?: string
          earnings_cents?: number
          id?: string
          is_approved?: boolean | null
          learner_id?: string
          learner_name?: string
          review_text?: string
          session_id?: string
          star_rating?: number | null
          submitted_at?: string | null
          word_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "reading_gym_reviews_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "reading_gym_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      reading_gym_sessions: {
        Row: {
          created_at: string | null
          created_by: string | null
          end_time: string | null
          id: string
          is_active: boolean | null
          session_name: string
          start_time: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          end_time?: string | null
          id?: string
          is_active?: boolean | null
          session_name: string
          start_time?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          end_time?: string | null
          id?: string
          is_active?: boolean | null
          session_name?: string
          start_time?: string | null
        }
        Relationships: []
      }
      stories: {
        Row: {
          author_name: string
          avg_external_rating: number | null
          category: string | null
          comments_count: number
          created_at: string
          external_rating_count: number | null
          full_story: string | null
          grade: string | null
          id: string
          is_registered_user: boolean
          likes_count: number
          main_character: string | null
          other_characters: string | null
          plot_adventure: string | null
          plot_beginning: string | null
          plot_ending: string | null
          plot_problem: string | null
          plot_solution: string | null
          school_id: string | null
          session_id: string | null
          status: string
          title: string
          updated_at: string
          user_id: string | null
          villain_challenge: string | null
          word_count: number | null
          world_setting: string | null
        }
        Insert: {
          author_name: string
          avg_external_rating?: number | null
          category?: string | null
          comments_count?: number
          created_at?: string
          external_rating_count?: number | null
          full_story?: string | null
          grade?: string | null
          id?: string
          is_registered_user?: boolean
          likes_count?: number
          main_character?: string | null
          other_characters?: string | null
          plot_adventure?: string | null
          plot_beginning?: string | null
          plot_ending?: string | null
          plot_problem?: string | null
          plot_solution?: string | null
          school_id?: string | null
          session_id?: string | null
          status?: string
          title: string
          updated_at?: string
          user_id?: string | null
          villain_challenge?: string | null
          word_count?: number | null
          world_setting?: string | null
        }
        Update: {
          author_name?: string
          avg_external_rating?: number | null
          category?: string | null
          comments_count?: number
          created_at?: string
          external_rating_count?: number | null
          full_story?: string | null
          grade?: string | null
          id?: string
          is_registered_user?: boolean
          likes_count?: number
          main_character?: string | null
          other_characters?: string | null
          plot_adventure?: string | null
          plot_beginning?: string | null
          plot_ending?: string | null
          plot_problem?: string | null
          plot_solution?: string | null
          school_id?: string | null
          session_id?: string | null
          status?: string
          title?: string
          updated_at?: string
          user_id?: string | null
          villain_challenge?: string | null
          word_count?: number | null
          world_setting?: string | null
        }
        Relationships: []
      }
      story_comments: {
        Row: {
          author_name: string
          content: string
          created_at: string
          id: string
          is_volunteer: boolean | null
          rating: number | null
          session_id: string | null
          story_id: string
          user_id: string | null
        }
        Insert: {
          author_name: string
          content: string
          created_at?: string
          id?: string
          is_volunteer?: boolean | null
          rating?: number | null
          session_id?: string | null
          story_id: string
          user_id?: string | null
        }
        Update: {
          author_name?: string
          content?: string
          created_at?: string
          id?: string
          is_volunteer?: boolean | null
          rating?: number | null
          session_id?: string | null
          story_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "story_comments_story_id_fkey"
            columns: ["story_id"]
            isOneToOne: false
            referencedRelation: "stories"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      volunteer_feedback: {
        Row: {
          created_at: string
          feedback_content: string
          id: string
          rating: number | null
          review_id: string
          updated_at: string
          volunteer_id: string | null
        }
        Insert: {
          created_at?: string
          feedback_content: string
          id?: string
          rating?: number | null
          review_id: string
          updated_at?: string
          volunteer_id?: string | null
        }
        Update: {
          created_at?: string
          feedback_content?: string
          id?: string
          rating?: number | null
          review_id?: string
          updated_at?: string
          volunteer_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "volunteer_feedback_review_id_fkey"
            columns: ["review_id"]
            isOneToOne: false
            referencedRelation: "book_reviews"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_student_leaderboard: {
        Args: never
        Returns: {
          avg_rating: number
          earnings: number
          grade: string
          language: string
          quality_score: number
          review_count: number
          school_id: string
          student_name: string
        }[]
      }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_volunteer_info: {
        Args: { volunteer_ids: string[] }
        Returns: {
          company_name: string
          full_name: string
          job_title: string
          user_id: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "volunteer" | "student" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}


type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">


type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]


export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never


export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never


export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never


export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never


export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never


export const Constants = {
  public: {
    Enums: {
      app_role: ["volunteer", "student", "admin"],
    },
  },
} as const
