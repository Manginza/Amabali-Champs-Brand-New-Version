import { supabase } from "@/integrations/supabase/client";


export const RATE_PER_WORD_CENTS = 2;
export const MIN_WORDS = 20;


export const AVATAR_OPTIONS = ["📚", "✍🏾", "🌟", "🦁", "🌺", "🎯", "🏆", "🔥"];


export const MILESTONES = [
  { words: 500, message: "Legend status! R10 in the bag! 🏆" },
  { words: 200, message: "R4 earned — you are a Reading Champ! 🌟" },
  { words: 100, message: "Halfway to R2! Amazing work! 💪" },
  { words: 50, message: "Great start! Keep going! 🔥" },
];


export function countWords(text: string): number {
  return text.trim().split(/\s+/).filter((w) => w.length > 0).length;
}


export function calcEarnings(wordCount: number): number {
  return wordCount * RATE_PER_WORD_CENTS;
}


export function formatRands(cents: number): string {
  return "R" + (cents / 100).toFixed(2);
}


export function getMilestone(wordCount: number) {
  return MILESTONES.find((m) => wordCount >= m.words) || null;
}


export async function fetchActiveSession() {
  const { data, error } = await supabase
    .from("reading_gym_sessions")
    .select("*")
    .eq("is_active", true)
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return data;
}


export async function fetchSessionReviews(sessionId: string) {
  const { data, error } = await supabase
    .from("reading_gym_reviews")
    .select("*")
    .eq("session_id", sessionId)
    .eq("is_approved", true)
    .order("submitted_at", { ascending: true });
  if (error) throw error;
  return data || [];
}


export async function submitReview(review: {
  session_id: string;
  learner_id: string;
  learner_name: string;
  avatar_emoji: string;
  book_title: string;
  book_author: string;
  star_rating: number;
  review_text: string;
  word_count: number;
  earnings_cents: number;
}) {
  const { data, error } = await supabase
    .from("reading_gym_reviews")
    .insert(review)
    .select()
    .single();
  if (error) throw error;
  return data;
}


// Admin functions
export async function fetchAllSessions() {
  const { data, error } = await supabase
    .from("reading_gym_sessions")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data || [];
}


export async function createSession(name: string, endTime?: string, userId?: string) {
  // Deactivate all other sessions first
  await supabase
    .from("reading_gym_sessions")
    .update({ is_active: false })
    .eq("is_active", true);


  const { data, error } = await supabase
    .from("reading_gym_sessions")
    .insert({
      session_name: name,
      end_time: endTime || null,
      is_active: true,
      created_by: userId || null,
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}


export async function toggleSessionActive(sessionId: string, activate: boolean) {
  if (activate) {
    await supabase
      .from("reading_gym_sessions")
      .update({ is_active: false })
      .eq("is_active", true);
  }
  const { error } = await supabase
    .from("reading_gym_sessions")
    .update({ is_active: activate })
    .eq("id", sessionId);
  if (error) throw error;
}


export async function fetchSessionReviewsAdmin(sessionId: string) {
  const { data, error } = await supabase
    .from("reading_gym_reviews")
    .select("*")
    .eq("session_id", sessionId)
    .order("submitted_at", { ascending: false });
  if (error) throw error;
  return data || [];
}


export async function toggleReviewApproval(reviewId: string, approved: boolean) {
  const { error } = await supabase
    .from("reading_gym_reviews")
    .update({ is_approved: approved })
    .eq("id", reviewId);
  if (error) throw error;
}


export interface LeaderboardEntry {
