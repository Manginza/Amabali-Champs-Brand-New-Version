import { useAuth } from "@/contexts/AuthContext";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  fetchAllSessions,
  createSession,
  toggleSessionActive,
  fetchSessionReviewsAdmin,
  toggleReviewApproval,
  formatRands,
  buildLeaderboard,
} from "@/lib/readingGym";
import { toast } from "sonner";
import { format } from "date-fns";
import { Download, Plus, Users, FileText, Coins, BookOpen } from "lucide-react";


export default function AdminReadingGymPage() {
  const { user, role, loading } = useAuth();
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<any[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(null);
  const [reviews, setReviews] = useState<any[]>([]);
  const [newName, setNewName] = useState("");
  const [newEndTime, setNewEndTime] = useState("");
  const [creating, setCreating] = useState(false);


  useEffect(() => {
    if (!loading && !user) {
      navigate("/admin-login", { replace: true });
    } else if (!loading && user && role !== null && role !== "admin") {
      navigate("/admin-login", { replace: true });
    }
  }, [loading, user, role, navigate]);


  useEffect(() => {
    if (user && role === "admin") {
      loadSessions();
    }
  }, [user, role]);


  useEffect(() => {
    if (selectedSessionId) {
      fetchSessionReviewsAdmin(selectedSessionId).then(setReviews).catch(console.error);
    }
  }, [selectedSessionId]);


  const loadSessions = async () => {
    const data = await fetchAllSessions();
    setSessions(data);
    if (data.length > 0 && !selectedSessionId) {
      setSelectedSessionId(data[0].id);
    }
  };


  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      await createSession(newName.trim(), newEndTime || undefined, user?.id);
      toast.success("Session created and activated!");
      setNewName("");
      setNewEndTime("");
      await loadSessions();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setCreating(false);
    }
  };


  const handleToggle = async (id: string, activate: boolean) => {
    try {
      await toggleSessionActive(id, activate);
      await loadSessions();
      toast.success(activate ? "Session activated" : "Session deactivated");
    } catch (e: any) {
      toast.error(e.message);
    }
  };


  const handleApprovalToggle = async (reviewId: string, approved: boolean) => {
    try {
      await toggleReviewApproval(reviewId, approved);
      setReviews((prev) =>
        prev.map((r) => (r.id === reviewId ? { ...r, is_approved: approved } : r))
      );
    } catch (e: any) {
      toast.error(e.message);
    }
  };


  // Summary stats
  const stats = useMemo(() => {
    const uniqueLearners = new Set(reviews.map((r) => r.learner_id)).size;
    const totalWords = reviews.reduce((s, r) => s + r.word_count, 0);
    const totalEarnings = reviews.reduce((s, r) => s + r.earnings_cents, 0);
    const bookCounts: Record<string, number> = {};
    reviews.forEach((r) => {
      bookCounts[r.book_title] = (bookCounts[r.book_title] || 0) + 1;
    });
    const mostReviewed = Object.entries(bookCounts).sort((a, b) => b[1] - a[1])[0];
    return { uniqueLearners, totalWords, totalEarnings, mostReviewed };
  }, [reviews]);


  const exportCSV = () => {
    const lb = buildLeaderboard(reviews.filter((r) => r.is_approved));
    const header = "Rank,Learner Name,Reviews,Total Words,Total Earnings\n";
    const rows = lb
      .map((e, i) => `${i + 1},"${e.learner_name}",${e.review_count},${e.total_words},${formatRands(e.total_earnings)}`)
      .join("\n");
    const blob = new Blob([header + rows], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "reading-gym-leaderboard.csv";
    a.click();
    URL.revokeObjectURL(url);
  };


  if (loading) return null;


  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 container max-w-6xl mx-auto px-4 py-6 space-y-6">
        <h1 className="font-display text-2xl font-bold text-foreground">🏋️ Reading Gym Admin</h1>


        {/* Create Session */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Create New Session</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Session name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="flex-1"
            />
            <Input
              type="datetime-local"
              value={newEndTime}
              onChange={(e) => setNewEndTime(e.target.value)}
              className="w-full sm:w-auto"
            />
            <Button onClick={handleCreate} disabled={creating || !newName.trim()}>
              <Plus className="w-4 h-4 mr-1" /> Create & Activate
            </Button>
          </CardContent>
        </Card>


        {/* Sessions List */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>End Time</TableHead>
                  <TableHead>Active</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sessions.map((s) => (
                  <TableRow
                    key={s.id}
                    className={selectedSessionId === s.id ? "bg-primary/5" : "cursor-pointer"}
                    onClick={() => setSelectedSessionId(s.id)}
                  >
                    <TableCell className="font-medium">{s.session_name}</TableCell>
                    <TableCell className="text-muted-foreground text-xs">
                      {format(new Date(s.created_at), "dd MMM yyyy HH:mm")}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-xs">
                      {s.end_time ? format(new Date(s.end_time), "dd MMM HH:mm") : "—"}
                    </TableCell>
                    <TableCell>
                      <Switch
                        checked={s.is_active}
                        onCheckedChange={(v) => handleToggle(s.id, v)}
                      />
                    </TableCell>
                    <TableCell>
                      {selectedSessionId === s.id && (
                        <span className="text-xs text-primary font-medium">Selected</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>


        {/* Summary Stats */}
        {selectedSessionId && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-5 flex items-center gap-3">
                <Users className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.uniqueLearners}</p>
                  <p className="text-xs text-muted-foreground">Learners</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 flex items-center gap-3">
                <FileText className="w-5 h-5 text-accent" />
                <div>
                  <p className="text-2xl font-bold text-foreground">{stats.totalWords.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">Total Words</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 flex items-center gap-3">
                <Coins className="w-5 h-5 text-success" />
                <div>
                  <p className="text-2xl font-bold text-foreground">{formatRands(stats.totalEarnings)}</p>
                  <p className="text-xs text-muted-foreground">Total Earnings</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-5 flex items-center gap-3">
                <BookOpen className="w-5 h-5 text-warning" />
                <div>
                  <p className="text-sm font-bold truncate text-foreground">
                    {stats.mostReviewed ? stats.mostReviewed[0] : "—"}
                  </p>
                  <p className="text-xs text-muted-foreground">Most Reviewed Book</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}


        {/* Reviews Table */}
        {selectedSessionId && (
          <Card>
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <CardTitle className="text-base">Reviews ({reviews.length})</CardTitle>
              <Button variant="outline" size="sm" onClick={exportCSV}>
                <Download className="w-4 h-4 mr-1" /> Export CSV
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Learner</TableHead>
                    <TableHead>Book</TableHead>
                    <TableHead>Words</TableHead>
                    <TableHead>Earnings</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead>Approved</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reviews.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-medium">{r.learner_name}</TableCell>
                      <TableCell>{r.book_title}</TableCell>
                      <TableCell>{r.word_count}</TableCell>
                      <TableCell className="text-success">{formatRands(r.earnings_cents)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {format(new Date(r.submitted_at), "HH:mm")}
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={r.is_approved}
                          onCheckedChange={(v) => handleApprovalToggle(r.id, v)}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </main>
      <Footer />
    </div>
  );
}


import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StarRating } from "@/components/StarRating";
import { ReviewGuidelines } from "@/components/ReviewGuidelines";
import { SEOHead } from "@/components/SEOHead";
import { useAuth } from "@/contexts/AuthContext";
