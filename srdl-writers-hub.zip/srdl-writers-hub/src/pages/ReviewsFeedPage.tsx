export default function ReviewsFeedPage() {
  const { user, role, profile } = useAuth();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [feedbackByReview, setFeedbackByReview] = useState<Record<string, Feedback[]>>({});
  const [loading, setLoading] = useState(true);
  const [newFeedback, setNewFeedback] = useState<Record<string, string>>({});
  const [editingFeedback, setEditingFeedback] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [expandedReviews, setExpandedReviews] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState("");


  const isVolunteer = role === "volunteer";


  const weightedScore = (avgRating: number | null, ratingCount: number | null) => {
    const r = avgRating || 0;
    const c = Math.min((ratingCount || 0) / 10, 1.0) * 5;
    return r * 0.7 + c * 0.3;
  };


  const filteredReviews = reviews
    .filter((review) => {
      const query = searchQuery.toLowerCase();
      return (
        review.book_name.toLowerCase().includes(query) ||
        review.student_name.toLowerCase().includes(query) ||
        review.review_title.toLowerCase().includes(query) ||
        review.review_content.toLowerCase().includes(query)
      );
    })
    .sort((a, b) => {
      const scoreDiff = weightedScore(b.avg_external_rating, b.external_rating_count) - weightedScore(a.avg_external_rating, a.external_rating_count);
      if (scoreDiff !== 0) return scoreDiff;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });


  useEffect(() => {
    fetchReviews();
  }, []);


  const fetchReviews = async () => {
    try {
      const { data: reviewsData, error: reviewsError } = await supabase
        .from("book_reviews")
        .select("*")
        .order("created_at", { ascending: false });


      if (reviewsError) throw reviewsError;
      setReviews((reviewsData || []).map(r => ({
        ...r,
        reward_status: (r.reward_status || 'pending') as Review['reward_status']
      })));


      // Fetch feedback for all reviews
      const { data: feedbackData, error: feedbackError } = await supabase
        .from("volunteer_feedback")
        .select("*")
        .order("created_at", { ascending: true });


      if (feedbackError) throw feedbackError;


      // Fetch volunteer profiles for feedback
      const volunteerIds = [...new Set((feedbackData || []).map(f => f.volunteer_id))];
      let volunteerProfiles: Record<string, any> = {};


      if (volunteerIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name, company_name, job_title")
          .in("user_id", volunteerIds);


        if (profiles) {
          profiles.forEach(p => {
            volunteerProfiles[p.user_id] = p;
          });
        }
      }


      // Group feedback by review
      const grouped: Record<string, Feedback[]> = {};
      (feedbackData || []).forEach(feedback => {
        const volunteer = volunteerProfiles[feedback.volunteer_id];
        const enrichedFeedback = {
          ...feedback,
          volunteer_name: volunteer?.full_name || "Unknown Volunteer",
          volunteer_company: volunteer?.company_name || "",
          volunteer_job_title: volunteer?.job_title || "",
        };
        
        if (!grouped[feedback.review_id]) {
          grouped[feedback.review_id] = [];
        }
        grouped[feedback.review_id].push(enrichedFeedback);
      });


      setFeedbackByReview(grouped);
    } catch (error: any) {
      console.error("Error fetching reviews:", error);
      toast({
        title: "Error loading reviews",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };


  const handleSubmitFeedbackWithRating = async (reviewId: string, rating: number | null, feedbackContent: string) => {
    setSubmitting(true);
    try {
      const { error } = await supabase.from("volunteer_feedback").insert({
        review_id: reviewId,
        volunteer_id: user?.id || null,
        feedback_content: feedbackContent,
        rating: rating,
      });


      if (error) throw error;


      toast({
        title: "Feedback submitted",
        description: rating !== null && rating < 50 
          ? "Feedback posted. The learner's reward has been revoked due to low rating."
          : "Your feedback has been posted.",
      });


      fetchReviews();
    } catch (error: any) {
      toast({
        title: "Error submitting feedback",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };


  const handleEditFeedback = async (feedbackId: string) => {
    if (!editContent.trim()) return;


    setSubmitting(true);
    try {
      const { error } = await supabase
        .from("volunteer_feedback")
        .update({ feedback_content: editContent })
        .eq("id", feedbackId);


      if (error) throw error;


      toast({
        title: "Feedback updated",
        description: "Your feedback has been updated.",
      });


      setEditingFeedback(null);
      setEditContent("");
      fetchReviews();
    } catch (error: any) {
      toast({
        title: "Error updating feedback",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };


  const handleDeleteFeedback = async (feedbackId: string) => {
    if (!confirm("Are you sure you want to delete this feedback?")) return;


    try {
      const { error } = await supabase
        .from("volunteer_feedback")
        .delete()
        .eq("id", feedbackId);


      if (error) throw error;


      toast({
        title: "Feedback deleted",
        description: "Your feedback has been removed.",
      });


      fetchReviews();
    } catch (error: any) {
      toast({
        title: "Error deleting feedback",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    }
  };


  const getSchoolName = (schoolId: string) => {
    return schools.find(s => s.id === schoolId)?.name || schoolId;
  };


  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };


  // Generate structured data for reviews list
  const reviewsListSchema = generateReviewsListSchema(
    reviews.map((review) => ({
      bookName: review.book_name,
      reviewerName: review.student_name,
      rating: review.star_rating,
      reviewUrl: `${typeof window !== "undefined" ? window.location.origin : ""}${generateReviewPath(review.book_name, review.student_name)}`,
    }))
  );


  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 md:pt-20">
      <SEOHead
        title="Student Book Reviews - SRDL Writers Hub"
        description="Read authentic book reviews from South African students. Discover new books through peer recommendations and earn rewards for your own reviews."
        keywords="student book reviews, book recommendations, peer reviews, reading community, South Africa education, children's books"
        structuredData={reviewsListSchema}
        canonicalUrl="/reviews-feed"
      />
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
            <h1 className="text-3xl font-display font-bold text-foreground">
              Student Book Reviews
            </h1>
            <p className="text-muted-foreground mt-1">
              {isVolunteer 
                ? "Review student submissions and provide constructive feedback" 
                : "Read reviews from fellow learners and volunteer feedback"}
            </p>
          </div>


          <div className="flex gap-3">
            {!user && (
              <Link to="/volunteer-auth">
                <Button variant="outline">
                  <LogIn className="w-4 h-4 mr-2" />
                  Volunteer Login
                </Button>
              </Link>
            )}
            <Link to="/book-review">
              <Button>
                <BookOpen className="w-4 h-4 mr-2" />
                Submit a Review
              </Button>
            </Link>
          </div>
        </div>


        {isVolunteer && profile && (
          <Card className="mb-6 border-primary/20 bg-primary/5">
            <CardContent className="py-4">
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {getInitials(profile.full_name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-foreground">
                    Welcome, {profile.full_name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {profile.job_title} at {profile.company_name}
                  </p>
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <Link to="/volunteer-dashboard">
                    <Button variant="outline" size="sm">
                      View Dashboard
                    </Button>
                  </Link>
                  <Badge className="bg-primary/20 text-primary">Volunteer</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}


        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search learner reviews by book, student, or content..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-card border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>


        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-muted-foreground">Loading reviews...</p>
          </div>
        ) : filteredReviews.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">
                {searchQuery ? "No reviews match your search" : "No reviews yet"}
              </h3>
              <p className="text-muted-foreground mb-6">
                {searchQuery ? "Try a different search term" : "Be the first to submit a book review!"}
              </p>
              {!searchQuery && (
                <Link to="/book-review">
                  <Button>Submit a Review</Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {filteredReviews.map((review) => (
              <Card key={review.id} className="overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-muted/50 to-transparent">
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-secondary to-warning flex items-center justify-center flex-shrink-0">
                        <BookOpen className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <Link 
                          to={generateReviewPath(review.book_name, review.student_name)}
                          className="hover:underline"
                        >
                          <CardTitle className="text-xl hover:text-primary transition-colors">
                            {review.review_title}
                          </CardTitle>
                        </Link>
                        <p className="text-primary font-medium mt-1">{review.book_name}</p>
                        <StarRating rating={review.star_rating} size="sm" />
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <ReviewStatusBadge status={review.reward_status} />
                      <Badge variant="outline" className="gap-1">
                        <User className="w-3 h-3" />
                        {review.student_name}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <Building2 className="w-3 h-3" />
                        {getSchoolName(review.school_id)}
                      </Badge>
                      <Badge variant="outline" className="gap-1">
                        <GraduationCap className="w-3 h-3" />
                        {review.grade}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <Collapsible
                    open={expandedReviews[review.id]}
                    onOpenChange={(open) => 
                      setExpandedReviews(prev => ({ ...prev, [review.id]: open }))
                    }
                  >
                    <p className={`text-foreground whitespace-pre-wrap leading-relaxed ${
                      !expandedReviews[review.id] ? "line-clamp-3" : ""
                    }`}>
                      {review.review_content}
                    </p>
                    <CollapsibleContent>
                      {/* This is intentionally empty - the content is shown via the className toggle above */}
                    </CollapsibleContent>
                    <CollapsibleTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="mt-2 text-primary hover:text-primary/80 p-0 h-auto"
                      >
                        {expandedReviews[review.id] ? (
                          <>
                            <ChevronUp className="w-4 h-4 mr-1" />
                            Show less
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-4 h-4 mr-1" />
                            Read full review
                          </>
                        )}
                      </Button>
                    </CollapsibleTrigger>
                  </Collapsible>
                  <div className="flex items-center justify-between mt-4">
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      Submitted on {format(new Date(review.created_at), "MMMM d, yyyy")}
                    </p>
                    <Link 
                      to={generateReviewPath(review.book_name, review.student_name)}
                      className="text-sm text-primary hover:underline flex items-center gap-1"
                    >
                      View details
                      <ExternalLink className="w-3 h-3" />
                    </Link>
                  </div>


                  {/* External Rating */}
                  <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-2">Rate this review:</p>
                    <ExternalRating
                      targetType="review"
                      targetId={review.id}
                      currentRating={review.avg_external_rating || 0}
                      ratingCount={review.external_rating_count || 0}
                      onRatingSubmitted={fetchReviews}
                    />
                  </div>


                  {/* Feedback Section */}
                  <div className="mt-6 pt-6 border-t border-border">
                    <h4 className="font-semibold text-foreground flex items-center gap-2 mb-4">
                      <MessageSquare className="w-5 h-5 text-primary" />
                      Volunteer Feedback ({feedbackByReview[review.id]?.length || 0})
                    </h4>


                    {feedbackByReview[review.id]?.map((feedback) => (
                      <div
                        key={feedback.id}
                        className="bg-muted/50 rounded-xl p-4 mb-3 last:mb-0"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3">
                            <Avatar className="w-8 h-8">
                              <AvatarFallback className="bg-primary/20 text-primary text-xs">
                                {getInitials(feedback.volunteer_name || "")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-sm">
                                  {feedback.volunteer_name}
                                </span>
                                {feedback.rating !== null && (
                                  <Badge 
                                    variant="outline" 
                                    className={`gap-1 ${
                                      feedback.rating < 50 
                                        ? "border-destructive/30 text-destructive" 
                                        : feedback.rating < 70 
                                        ? "border-warning/30 text-warning" 
                                        : "border-success/30 text-success"
                                    }`}
                                  >
                                    <Percent className="w-3 h-3" />
                                    {feedback.rating}%
                                  </Badge>
                                )}
                                {feedback.volunteer_company && (
                                  <span className="text-xs text-muted-foreground">
                                    {feedback.volunteer_job_title} at {feedback.volunteer_company}
                                  </span>
                                )}
                              </div>
                              {editingFeedback === feedback.id ? (
                                <div className="mt-2 space-y-2">
                                  <Textarea
                                    value={editContent}
                                    onChange={(e) => setEditContent(e.target.value)}
                                    rows={3}
                                  />
                                  <div className="flex gap-2">
                                    <Button
                                      size="sm"
                                      onClick={() => handleEditFeedback(feedback.id)}
                                      disabled={submitting}
                                    >
                                      Save
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        setEditingFeedback(null);
                                        setEditContent("");
                                      }}
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <p className="text-sm text-foreground mt-1">
                                  {feedback.feedback_content}
                                </p>
                              )}
                              <p className="text-xs text-muted-foreground mt-2">
                                {format(new Date(feedback.created_at), "MMM d, yyyy 'at' h:mm a")}
                                {feedback.updated_at !== feedback.created_at && " (edited)"}
                              </p>
                            </div>
                          </div>
                          {isVolunteer && feedback.volunteer_id === user?.id && editingFeedback !== feedback.id && (
                            <div className="flex gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8"
                                onClick={() => {
                                  setEditingFeedback(feedback.id);
                                  setEditContent(feedback.feedback_content);
                                }}
                              >
                                <Edit2 className="w-4 h-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-8 w-8 text-destructive"
                                onClick={() => handleDeleteFeedback(feedback.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}


                    {/* New Feedback Input - Available to everyone */}
                    {isVolunteer && !feedbackByReview[review.id]?.some(f => f.volunteer_id === user?.id) ? (
                      <div className="mt-4">
                        <VolunteerRatingSlider
                          onSubmit={async (rating, feedback) => {
                            await handleSubmitFeedbackWithRating(review.id, rating, feedback);
                          }}
                          disabled={submitting}
                        />
                      </div>
                    ) : !isVolunteer && (
                      <div className="mt-4 space-y-3">
                        <Textarea
                          placeholder="Share your thoughts on this review..."
                          value={newFeedback[review.id] || ""}
                          onChange={(e) => setNewFeedback(prev => ({ ...prev, [review.id]: e.target.value }))}
                          rows={3}
                          className="resize-none"
                        />
                        <Button
                          onClick={async () => {
                            if (!newFeedback[review.id]?.trim()) return;
                            await handleSubmitFeedbackWithRating(review.id, null, newFeedback[review.id]);
                            setNewFeedback(prev => ({ ...prev, [review.id]: "" }));
                          }}
                          disabled={submitting || !newFeedback[review.id]?.trim()}
                          size="sm"
                        >
                          <Send className="w-4 h-4 mr-2" />
                          Post Comment
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}


import { useEffect } from "react";
import { useNavigate } from "react-router-dom";


// This page is deprecated - redirect to the proper book review page
const ReviewsPage = () => {
  const navigate = useNavigate();


  useEffect(() => {
    // Redirect to the proper book review page that saves to database
    navigate("/book-review", { replace: true });
  }, [navigate]);


  return null;
};


export default ReviewsPage;
