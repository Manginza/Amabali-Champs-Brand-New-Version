import { useAuth } from "@/contexts/AuthContext";
import { schools } from "@/data/schools";
import { 
  BookOpen, 
  Sparkles, 
  Target, 
  Award,
  ArrowRight,
  Trophy,
  Users,
  FileText,
  Star,
  Coins,
  PenLine,
  LogIn
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";


const Index = () => {
  const { learner, updateLearner } = useLearner();
  const [showNameInput, setShowNameInput] = useState(false);
  const [tempName, setTempName] = useState(learner.name);


  const selectedSchool = schools.find((s) => s.id === learner.schoolId);
  const isReturningUser = learner.name && learner.name.trim() !== "";


  const handleNameSubmit = () => {
    if (tempName.trim()) {
      updateLearner({ name: tempName.trim() });
      setShowNameInput(false);
    }
  };


  // Show personalized dashboard for returning users
  if (isReturningUser && !showNameInput) {
    return (
      <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
        <Navbar />


        <main className="container mx-auto px-4 py-6 max-w-6xl">
          {/* Welcome Section */}
          <section className="mb-8 animate-slide-up">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
                  Hello, <span className="text-gradient-teal">{learner.name}</span>! 👋
                </h1>
                <p className="text-muted-foreground">
                  {selectedSchool 
                    ? `${selectedSchool.name} • Grade ${learner.grade || "?"}`
                    : "Ready for another reading adventure?"
                  }
                </p>
              </div>
              <SchoolSelector compact showGrade />
            </div>
          </section>


          {/* Stats Overview */}
          <section className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-card rounded-2xl p-4 border border-border shadow-soft animate-slide-up" style={{ animationDelay: "100ms" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-card-teal flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-display font-bold text-foreground">{learner.storiesRead}</p>
                  <p className="text-xs text-muted-foreground">Stories Read</p>
                </div>
              </div>
            </div>


            <div className="bg-card rounded-2xl p-4 border border-border shadow-soft animate-slide-up" style={{ animationDelay: "150ms" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-card-orange flex items-center justify-center">
                  <Target className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <p className="text-2xl font-display font-bold text-foreground">{learner.storiesWritten}</p>
                  <p className="text-xs text-muted-foreground">Stories Written</p>
                </div>
              </div>
            </div>


            <div className="bg-card rounded-2xl p-4 border border-border shadow-soft animate-slide-up" style={{ animationDelay: "200ms" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-card-purple flex items-center justify-center">
                  <Award className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-display font-bold text-foreground">{learner.badges.length}</p>
                  <p className="text-xs text-muted-foreground">Badges Earned</p>
                </div>
              </div>
            </div>


            <div className="bg-card rounded-2xl p-4 border border-border shadow-soft animate-slide-up" style={{ animationDelay: "250ms" }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-success flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="text-2xl font-display font-bold text-foreground">{learner.totalPoints}</p>
                  <p className="text-xs text-muted-foreground">Total Points</p>
                </div>
              </div>
            </div>
          </section>


          {/* Reading Streak */}
          <section className="mb-8 animate-slide-up" style={{ animationDelay: "300ms" }}>
            <ReadingStreakCard />
          </section>


          {/* Quick Actions */}
          <section className="mb-8">
            <h2 className="font-display text-xl font-bold text-foreground mb-4">
              What would you like to do?
            </h2>
            <QuickActionsGrid />
          </section>


          {/* Recent Badges */}
          <section className="mb-8 animate-slide-up" style={{ animationDelay: "400ms" }}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-xl font-bold text-foreground">
                Your Achievements
              </h2>
              <Link to="/profile" className="text-sm text-primary hover:underline">
                View All
              </Link>
            </div>
            <div className="bg-card rounded-2xl p-6 border border-border shadow-soft">
              <div className="flex flex-wrap gap-6 justify-center sm:justify-start">
                {["First Login", "First Story Read", "7-Day Streak", "First Story Written", "100 Words Written"].map((badge) => (
                  <AchievementBadge 
                    key={badge} 
                    name={badge} 
                    unlocked={learner.badges.includes(badge)}
                  />
                ))}
              </div>
            </div>
          </section>
        </main>
        <Footer />
      </div>
    );
  }


  // Show onboarding form
  if (showNameInput) {
    return (
      <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
        <Navbar />
        <main className="container mx-auto px-4 py-6 max-w-6xl">
          <section className="max-w-md mx-auto mt-12 animate-slide-up">
            <div className="bg-card rounded-2xl p-6 shadow-soft border border-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-purple flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-xl text-foreground">
                    Welcome to SRDL Hub!
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Let's start your reading adventure
                  </p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    What's your name?
                  </label>
                  <Input
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    placeholder="Enter your name"
                    className="text-lg"
                    onKeyDown={(e) => e.key === "Enter" && handleNameSubmit()}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    Select your school and grade
                  </label>
                  <SchoolSelector />
                </div>


                <Button 
                  onClick={handleNameSubmit}
                  className="w-full bg-gradient-teal hover:opacity-90 text-white font-semibold"
                  disabled={!tempName.trim()}
                >
                  Start My Adventure
                </Button>
              </div>
            </div>
          </section>
        </main>
        <Footer />
      </div>
    );
  }


  // Landing page (SRDL Writers & Reader's Hub)
  return (
    <div className="min-h-screen bg-[linear-gradient(135deg,#1a1040_0%,#2d1b69_50%,#1a1040_100%)] pb-24 md:pb-8 md:pt-20">
      <Navbar />


      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center py-12 md:py-20">
          <div className="animate-slide-up">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Sparkles className="w-8 h-8 text-secondary animate-sparkle" />
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold">
                <span className="text-white">SRDL </span>
                <span className="text-gradient-orange">Writers & Reader's</span>
                <span className="text-white"> Hub</span>
              </h1>
              <Sparkles className="w-8 h-8 text-secondary animate-sparkle" />
            </div>
            
            <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto mb-10">
              Unleash your creativity, write amazing stories, and earn rewards while improving your skills!
            </p>
          </div>


          {/* CTA Buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-16 animate-slide-up" style={{ animationDelay: "200ms" }}>
            <Button 
              onClick={() => setShowNameInput(true)}
              className="gap-2 bg-gradient-orange hover:opacity-90 text-white font-semibold px-8 py-6 text-lg rounded-xl shadow-glow-orange"
            >
              Start Writing Now
              <ArrowRight className="w-5 h-5" />
            </Button>
            
            <Link to="/reading">
              <Button 
                variant="outline" 
                className="gap-2 border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-6 text-lg rounded-xl"
              >
                <BookOpen className="w-5 h-5" />
                Reading Gym
              </Button>
            </Link>
            
            <Link to="/leaderboard">
              <Button 
                variant="outline" 
                className="gap-2 border-2 border-white/50 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-xl"
              >
                <Trophy className="w-5 h-5" />
                View Leaderboard
              </Button>
            </Link>
          </div>


          {/* Stats Section */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 max-w-4xl mx-auto animate-slide-up" style={{ animationDelay: "400ms" }}>
            {[
              { icon: Users, value: "1000+", label: "Young Writers", color: "text-secondary" },
              { icon: FileText, value: "5000+", label: "Stories Created", color: "text-secondary" },
              { icon: Star, value: "10000+", label: "Words Written", color: "text-secondary" },
              { icon: Coins, value: "R500+", label: "Earned by Authors", color: "text-secondary" },
            ].map((stat, index) => (
              <div
                key={stat.label}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 text-center border border-white/10 card-hover"
                style={{ animationDelay: `${500 + index * 100}ms` }}
              >
                <stat.icon className={`w-8 h-8 ${stat.color} mx-auto mb-3`} />
                <p className="text-3xl md:text-4xl font-display font-bold text-white mb-1">
                  {stat.value}
                </p>
                <p className="text-sm text-white/70">{stat.label}</p>
              </div>
            ))}
          </div>
        </section>


        {/* How It Works Section */}
        <section className="py-12">
          <h2 className="text-2xl md:text-3xl font-display font-bold text-white text-center mb-8 animate-slide-up">
            How It Works
          </h2>


          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                icon: BookOpen,
                title: "1. Read Books",
                description: "Explore our library and find books that interest you at your reading level.",
                gradient: "bg-gradient-teal",
              },
              {
                icon: PenLine,
                title: "2. Write Reviews",
                description: "Share your thoughts in reviews with at least 30 words to qualify.",
                gradient: "bg-gradient-orange",
              },
              {
                icon: Coins,
                title: "3. Earn Rewards",
                description: "Get R2 for each approved review. Cash out when you reach R50!",
                gradient: "bg-gradient-purple",
              },
            ].map((step, index) => (
              <div
                key={step.title}
                className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl text-center border border-white/10 card-hover animate-slide-up"
                style={{ animationDelay: `${700 + index * 100}ms` }}
              >
                <div className={`w-14 h-14 rounded-xl ${step.gradient} flex items-center justify-center mx-auto mb-4`}>
                  <step.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-display text-lg font-bold text-white mb-2">
                  {step.title}
                </h3>
                <p className="text-sm text-white/70">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </section>


        {/* Quick Links */}
        <section className="py-12 text-center animate-slide-up" style={{ animationDelay: "1000ms" }}>
          <p className="text-white/70 mb-4">Ready to start your writing journey?</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              onClick={() => setShowNameInput(true)}
              className="gap-2 bg-gradient-orange hover:opacity-90 text-white font-semibold px-8 py-6 text-lg rounded-xl shadow-glow-orange"
            >
              <PenLine className="w-5 h-5" />
              Submit Your First Review
            </Button>
            <Link to="/student-auth">
              <Button 
                variant="outline" 
                className="gap-2 border-2 border-white/50 text-white hover:bg-white/10 px-8 py-6 text-lg rounded-xl"
              >
                <LogIn className="w-5 h-5" />
                Student Login
              </Button>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};


export default Index;
