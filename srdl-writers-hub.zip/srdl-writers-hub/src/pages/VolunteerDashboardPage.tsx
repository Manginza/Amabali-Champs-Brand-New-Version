export default function VolunteerDashboardPage() {
  const navigate = useNavigate();
  const { user, profile, role, signOut, loading } = useAuth();
  const [feedbackHistory, setFeedbackHistory] = useState<FeedbackWithReview[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalReviews: 0,
    averageRating: 0,
    highRatings: 0,
    lowRatings: 0,
    rewardsConfirmed: 0,
    rewardsRevoked: 0
  });
  const [loadingData, setLoadingData] = useState(true);


  useEffect(() => {
    if (!loading && !user) {
      navigate("/volunteer-auth");
    }
    if (!loading && role !== "volunteer") {
      navigate("/");
    }
  }, [user, loading, role, navigate]);


  useEffect(() => {
    if (user && role === "volunteer") {
      fetchDashboardData();
    }
  }, [user, role]);


  const fetchDashboardData = async () => {
    try {
      // Fetch all feedback by this volunteer
      const { data: feedbackData, error: feedbackError } = await supabase
        .from("volunteer_feedback")
        .select("id, feedback_content, rating, created_at, review_id")
        .eq("volunteer_id", user?.id)
        .order("created_at", { ascending: false });


      if (feedbackError) throw feedbackError;


      const reviewIds = feedbackData?.map(f => f.review_id) || [];
      
      if (reviewIds.length > 0) {
        // Fetch related reviews
        const { data: reviews } = await supabase
          .from("book_reviews")
          .select("id, review_title, book_name, student_name, school_id, grade, star_rating, reward_status")
          .in("id", reviewIds);


        const reviewMap: Record<string, any> = {};
        reviews?.forEach(r => {
          reviewMap[r.id] = r;
        });


        const enrichedFeedback: FeedbackWithReview[] = feedbackData?.map(f => ({
          ...f,
          review_title: reviewMap[f.review_id]?.review_title || "Unknown Review",
          book_name: reviewMap[f.review_id]?.book_name || "Unknown Book",
          student_name: reviewMap[f.review_id]?.student_name || "Unknown Student",
          school_id: reviewMap[f.review_id]?.school_id || "",
          grade: reviewMap[f.review_id]?.grade || "",
          star_rating: reviewMap[f.review_id]?.star_rating || 0,
          reward_status: reviewMap[f.review_id]?.reward_status || "pending",
        })) || [];


        setFeedbackHistory(enrichedFeedback);


        // Calculate statistics
        const ratedFeedback = enrichedFeedback.filter(f => f.rating !== null);
        const totalRatings = ratedFeedback.length;
        const avgRating = totalRatings > 0 
          ? ratedFeedback.reduce((sum, f) => sum + (f.rating || 0), 0) / totalRatings 
          : 0;
        const highRatings = ratedFeedback.filter(f => (f.rating || 0) >= 50).length;
        const lowRatings = ratedFeedback.filter(f => (f.rating || 0) < 50).length;
        const rewardsConfirmed = enrichedFeedback.filter(f => f.reward_status === "rewarded").length;
        const rewardsRevoked = enrichedFeedback.filter(f => f.reward_status === "revoked").length;


        setStats({
          totalReviews: enrichedFeedback.length,
          averageRating: Math.round(avgRating),
          highRatings,
          lowRatings,
          rewardsConfirmed,
          rewardsRevoked
        });
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoadingData(false);
    }
  };


  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };


  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };


  const getSchoolName = (schoolId: string) => {
    return schools.find(s => s.id === schoolId)?.name || schoolId;
  };


  const getRatingColor = (rating: number) => {
    if (rating < 50) return "text-destructive";
    if (rating < 70) return "text-warning";
    return "text-success";
  };


  const getRatingBadgeClass = (rating: number) => {
    if (rating < 50) return "border-destructive/30 bg-destructive/10 text-destructive";
    if (rating < 70) return "border-warning/30 bg-warning/10 text-warning";
    return "border-success/30 bg-success/10 text-success";
  };


  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }


  if (!user || !profile || role !== "volunteer") {
    return null;
  }


  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 md:pt-20">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <Link
          to="/reviews-feed"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Reviews
        </Link>


        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground">Volunteer Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Track your feedback and impact on student reviews
          </p>
        </div>


        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Profile Card */}
          <Card className="lg:col-span-1">
            <CardHeader className="text-center">
              <Avatar className="w-20 h-20 mx-auto mb-4">
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-xl">
                  {getInitials(profile.full_name)}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="text-xl">{profile.full_name}</CardTitle>
              <Badge className="mx-auto mt-2 bg-primary/20 text-primary">
                Volunteer
              </Badge>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Building2 className="w-4 h-4 text-primary" />
                <span>{profile.company_name || "Not specified"}</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Briefcase className="w-4 h-4 text-primary" />
                <span>{profile.job_title || "Not specified"}</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Mail className="w-4 h-4 text-primary" />
                <span className="truncate">{profile.email}</span>
              </div>
              {profile.phone_number && (
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4 text-primary" />
                  <span>{profile.phone_number}</span>
                </div>
              )}


              <div className="pt-4 space-y-2">
                <Link to="/reviews-feed">
                  <Button className="w-full" size="sm">
                    <BookOpen className="w-4 h-4 mr-2" />
                    Review More
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  className="w-full"
                  size="sm"
                  onClick={handleSignOut}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </CardContent>
          </Card>


          {/* Stats & Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Statistics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <MessageSquare className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-foreground">{stats.totalReviews}</p>
                      <p className="text-xs text-muted-foreground">Reviews Rated</p>
                    </div>
                  </div>
                </CardContent>
              </Card>


              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                      <BarChart3 className="w-5 h-5 text-secondary" />
                    </div>
                    <div>
                      <p className={`text-2xl font-bold ${getRatingColor(stats.averageRating)}`}>
                        {stats.averageRating}%
                      </p>
                      <p className="text-xs text-muted-foreground">Avg Rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>


              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
                      <ThumbsUp className="w-5 h-5 text-success" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-success">{stats.highRatings}</p>
                      <p className="text-xs text-muted-foreground">Pass (≥50%)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>


              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                      <ThumbsDown className="w-5 h-5 text-destructive" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-destructive">{stats.lowRatings}</p>
                      <p className="text-xs text-muted-foreground">Fail (&lt;50%)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>


            {/* Impact Summary */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Your Impact</CardTitle>
                    <CardDescription>How your ratings affect learner rewards</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground flex items-center gap-2">
                        <Award className="w-4 h-4 text-success" />
                        Rewards Confirmed
                      </span>
                      <span className="font-semibold text-success">{stats.rewardsConfirmed}</span>
                    </div>
                    <Progress 
                      value={stats.totalReviews > 0 ? (stats.rewardsConfirmed / stats.totalReviews) * 100 : 0} 
                      className="h-2"
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground flex items-center gap-2">
                        <ThumbsDown className="w-4 h-4 text-destructive" />
                        Rewards Revoked
                      </span>
                      <span className="font-semibold text-destructive">{stats.rewardsRevoked}</span>
                    </div>
                    <Progress 
                      value={stats.totalReviews > 0 ? (stats.rewardsRevoked / stats.totalReviews) * 100 : 0} 
                      className="h-2 [&>div]:bg-destructive"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>


            {/* Feedback History */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-secondary to-warning flex items-center justify-center">
                      <MessageSquare className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">Reviews You've Rated</CardTitle>
                      <CardDescription>Complete history of your feedback</CardDescription>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loadingData ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full mx-auto" />
                  </div>
                ) : feedbackHistory.length === 0 ? (
                  <div className="text-center py-8">
                    <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No reviews rated yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start helping students by reviewing their book reviews.
                    </p>
                    <Link to="/reviews-feed">
                      <Button>
                        <BookOpen className="w-4 h-4 mr-2" />
                        Browse Reviews
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {feedbackHistory.map((feedback) => (
                      <div
                        key={feedback.id}
                        className="p-4 rounded-xl border border-border bg-muted/30 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-3">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-secondary to-warning flex items-center justify-center flex-shrink-0">
                              <BookOpen className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <Link 
                                to={generateReviewPath(feedback.book_name, feedback.student_name)}
                                className="font-semibold text-foreground hover:text-primary transition-colors"
                              >
                                {feedback.review_title}
                              </Link>
                              <p className="text-sm text-primary">{feedback.book_name}</p>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <Badge variant="outline" className="text-xs gap-1">
                                  <Users className="w-3 h-3" />
                                  {feedback.student_name}
                                </Badge>
                                <Badge variant="outline" className="text-xs gap-1">
                                  <Building2 className="w-3 h-3" />
                                  {getSchoolName(feedback.school_id)}
                                </Badge>
                                <Badge variant="outline" className="text-xs gap-1">
                                  {feedback.grade}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                            {feedback.rating !== null && (
                              <Badge className={`gap-1 ${getRatingBadgeClass(feedback.rating)}`}>
                                <Percent className="w-3 h-3" />
                                {feedback.rating}%
                              </Badge>
                            )}
                            <Badge 
                              variant="outline" 
                              className={`gap-1 ${
                                feedback.reward_status === "rewarded" 
                                  ? "border-success/30 text-success" 
                                  : feedback.reward_status === "revoked"
                                  ? "border-destructive/30 text-destructive"
                                  : "border-muted-foreground/30"
                              }`}
                            >
                              <Award className="w-3 h-3" />
                              {feedback.reward_status === "rewarded" ? "Rewarded" : 
                               feedback.reward_status === "revoked" ? "Revoked" : "Pending"}
                            </Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1 whitespace-nowrap">
                              <Calendar className="w-3 h-3" />
                              {format(new Date(feedback.created_at), "MMM d, yyyy")}
                            </span>
                          </div>
                        </div>
                        <div className="pl-13">
                          <p className="text-sm text-muted-foreground bg-background/50 rounded-lg p-3">
                            "{feedback.feedback_content}"
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
 import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { 
  ArrowLeft, 
  Building2, 
  Briefcase, 
  Mail, 
  Phone,
  MessageSquare,
  Calendar,
  LogOut,
  BookOpen
} from "lucide-react";
import { format } from "date-fns";


interface FeedbackHistory {
  id: string;
  feedback_content: string;
  created_at: string;
  review_title: string;
  book_name: string;
  student_name: string;
}


export default function VolunteerProfilePage() {
