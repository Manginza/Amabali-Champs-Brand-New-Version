export default ReadingPage;
import { useParams, Link, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/StarRating";
import { SEOHead, generateReviewSchema } from "@/components/SEOHead";
import { supabase } from "@/integrations/supabase/client";
import { schools } from "@/data/schools";
import { slugify } from "@/lib/slugify";
import { 
  ArrowLeft, 
  BookOpen, 
  User, 
  School, 
  Calendar,
  Share2,
  ChevronRight
} from "lucide-react";
import { format } from "date-fns";


const ReviewDetailPage = () => {
  const { bookSlug, studentSlug } = useParams<{ bookSlug: string; studentSlug: string }>();
  const navigate = useNavigate();


  const { data: review, isLoading, error } = useQuery({
    queryKey: ["review", bookSlug, studentSlug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("book_reviews")
        .select("*")
        .order("created_at", { ascending: false });


      if (error) throw error;


      // Find the review matching the slugs
      const matchingReview = data?.find((r) => {
        const bookMatch = slugify(r.book_name) === bookSlug;
        const studentMatch = slugify(r.student_name) === studentSlug;
        return bookMatch && studentMatch;
      });


      return matchingReview || null;
    },
    enabled: !!bookSlug && !!studentSlug,
  });


  const getSchoolName = (schoolId: string) => {
    const school = schools.find((s) => s.id === schoolId);
    return school?.name || schoolId;
  };


  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${review?.book_name} Review by ${review?.student_name}`,
          text: review?.review_content.slice(0, 150) + "...",
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled or error
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };


  if (isLoading) {
    return (
      <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-1 flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">Loading review...</div>
        </div>
        <Footer />
      </div>
    );
  }


  if (error || !review) {
    return (
      <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-display font-bold text-foreground mb-4">
              Review Not Found
            </h1>
            <p className="text-muted-foreground mb-6">
              This review may have been removed or doesn't exist.
            </p>
            <Button onClick={() => navigate("/reviews-feed")}>
              View All Reviews
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }


  const schoolName = getSchoolName(review.school_id);
  const formattedDate = format(new Date(review.created_at), "MMMM d, yyyy");


  // Generate structured data for SEO with enhanced book information
  const structuredData = generateReviewSchema({
    bookName: review.book_name,
    reviewerName: review.student_name,
    rating: review.star_rating,
    reviewContent: review.review_content,
    datePublished: review.created_at,
    schoolName: schoolName,
    language: review.language || "en",
  });


  return (
    <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
      <SEOHead
        title={`${review.book_name} Review by ${review.student_name} - SRDL Writers Hub`}
        description={review.review_content.slice(0, 155) + "..."}
        keywords={`${review.book_name}, book review, ${review.student_name}, ${schoolName}, student review`}
        ogType="article"
        canonicalUrl={`/reviews/${bookSlug}/${studentSlug}`}
        structuredData={structuredData}
      />
      <Navbar />


      <main className="container mx-auto px-4 py-8 flex-1">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6 flex-wrap">
          <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
          <ChevronRight className="w-4 h-4" />
          <Link to="/reviews-feed" className="hover:text-foreground transition-colors">Reviews</Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground truncate max-w-[200px]">{review.book_name}</span>
        </nav>


        <div className="max-w-3xl mx-auto">
          {/* Review Card */}
          <article className="bg-card rounded-3xl border border-border shadow-soft overflow-hidden">
            {/* Header */}
            <header className="bg-gradient-to-br from-[#4B0082] via-[#6B238E] to-[#4B0082] p-8 text-white">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-display font-bold mb-2">
                    {review.review_title || `Review of ${review.book_name}`}
                  </h1>
                  <div className="flex items-center gap-2 text-white/80">
                    <BookOpen className="w-4 h-4" />
                    <span className="font-medium">{review.book_name}</span>
                  </div>
                </div>
                <StarRating rating={review.star_rating} size="lg" />
              </div>


              <div className="flex flex-wrap items-center gap-4 text-sm text-white/70">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span>{review.student_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <School className="w-4 h-4" />
                  <span>{schoolName}</span>
                </div>
                {review.grade && (
                  <span className="px-2 py-0.5 rounded-full bg-white/20 text-xs">
                    Grade {review.grade}
                  </span>
                )}
              </div>
            </header>


            {/* Content */}
            <div className="p-8">
              <div className="prose prose-lg max-w-none text-foreground">
                <p className="text-lg leading-relaxed whitespace-pre-wrap">
                  {review.review_content}
                </p>
              </div>


              {/* Meta info */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <time dateTime={review.created_at}>{formattedDate}</time>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleShare}
                  className="gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
              </div>
            </div>
          </article>


          {/* Back to reviews */}
          <div className="mt-8 text-center">
            <Link to="/reviews-feed">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to All Reviews
              </Button>
            </Link>
          </div>
        </div>
      </main>


      <Footer />
    </div>
  );
};


export default ReviewDetailPage;
