import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { SchoolSelector } from "@/components/SchoolSelector";
import { AchievementBadge } from "@/components/AchievementBadge";
import { useLearner } from "@/contexts/LearnerContext";
import { schools } from "@/data/schools";
import { 
  Settings, 
  Award, 
  Clock, 
  BookOpen, 
  PenTool,
  Sparkles,
  Target,
  Flame,
  Edit2,
  Check,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";


const allBadges = [
  "First Login",
  "First Story Read", 
  "7-Day Streak",
  "First Story Written",
  "100 Words Written",
  "Reading Champion",
  "Super Writer",
  "Speed Reader",
  "Goal Crusher",
  "Helpful Friend",
];


const ProfilePage = () => {
  const { learner, updateLearner } = useLearner();
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(learner.name);


  const selectedSchool = schools.find((s) => s.id === learner.schoolId);


  const handleSaveName = () => {
    if (tempName.trim()) {
      updateLearner({ name: tempName.trim() });
      setIsEditingName(false);
      toast({
        title: "Name updated!",
        description: "Your profile has been updated.",
      });
    }
  };


  const recentActivity = [
    { action: "Completed a story", detail: "The Friendly Lion", time: "2 hours ago", points: 10 },
    { action: "Earned a badge", detail: "First Story Read", time: "Yesterday", points: 25 },
    { action: "Published a story", detail: "My School Adventure", time: "2 days ago", points: 50 },
  ];


  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Profile Header */}
        <div className="flex flex-col items-center text-center mb-8 animate-slide-up">
          <div className="relative mb-4">
            <div className="w-24 h-24 rounded-full bg-gradient-teal flex items-center justify-center shadow-glow-teal">
              <span className="text-4xl font-display font-bold text-white">
                {learner.name ? learner.name.charAt(0).toUpperCase() : "?"}
              </span>
            </div>
            <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-success flex items-center justify-center shadow-md border-2 border-background">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
          </div>


          {isEditingName ? (
            <div className="flex items-center gap-2 mb-2">
              <Input
                value={tempName}
                onChange={(e) => setTempName(e.target.value)}
                className="text-center font-display font-bold text-xl w-48"
                autoFocus
              />
              <Button size="icon" variant="ghost" onClick={handleSaveName}>
                <Check className="w-4 h-4 text-success" />
              </Button>
              <Button size="icon" variant="ghost" onClick={() => setIsEditingName(false)}>
                <X className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-2xl font-display font-bold text-foreground">
                {learner.name || "Young Reader"}
              </h1>
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-8 w-8"
                onClick={() => {
                  setTempName(learner.name);
                  setIsEditingName(true);
                }}
              >
                <Edit2 className="w-4 h-4 text-muted-foreground" />
              </Button>
            </div>
          )}


          <p className="text-muted-foreground text-sm mb-4">
            {selectedSchool ? `${selectedSchool.name} • Grade ${learner.grade || "?"}` : "Select your school below"}
          </p>


          <SchoolSelector />


          {/* Points Badge */}
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-5 py-2 mt-4">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="font-bold text-primary">{learner.totalPoints} points earned</span>
          </div>
        </div>


        {/* Reading Streak Card */}
        <div className="bg-card-orange rounded-2xl p-6 mb-6 animate-slide-up" style={{ animationDelay: "100ms" }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                <Flame className="w-6 h-6 text-foreground" />
              </div>
              <div>
                <h2 className="font-display text-lg font-bold text-foreground">Reading Streak</h2>
                <p className="text-sm text-foreground/70">Keep it going!</p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-4xl font-display font-bold text-foreground">{learner.readingStreak}</span>
              <p className="text-xs text-foreground/70">days</p>
            </div>
          </div>
          <Progress value={(learner.readingStreak % 7) / 7 * 100} className="h-2 bg-white/20" />
          <p className="text-xs text-foreground/60 mt-2">
            {7 - (learner.readingStreak % 7)} more days to earn a streak badge!
          </p>
        </div>


        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {[
            { icon: BookOpen, label: "Stories Read", value: learner.storiesRead.toString(), color: "text-primary", bg: "bg-card-teal" },
            { icon: PenTool, label: "Stories Written", value: learner.storiesWritten.toString(), color: "text-secondary", bg: "bg-card-orange" },
            { icon: Award, label: "Badges Earned", value: `${learner.badges.length} / ${allBadges.length}`, color: "text-accent", bg: "bg-card-purple" },
            { icon: Target, label: "Reading Level", value: learner.storiesRead < 5 ? "Entry" : learner.storiesRead < 15 ? "Intermediate" : "Advanced", color: "text-success", bg: "bg-muted" },
          ].map((stat, index) => (
            <div
              key={stat.label}
              className={cn(
                "rounded-2xl p-4 animate-slide-up",
                stat.bg
              )}
              style={{ animationDelay: `${200 + index * 50}ms` }}
            >
              <stat.icon className={cn("w-5 h-5 mb-2", stat.color)} />
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs text-foreground/70">{stat.label}</p>
            </div>
          ))}
        </div>


        {/* Recent Activity */}
        <div className="bg-card rounded-2xl border border-border p-6 mb-6 animate-slide-up" style={{ animationDelay: "400ms" }}>
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-muted-foreground" />
            <h2 className="font-display text-lg font-semibold text-foreground">Recent Activity</h2>
          </div>


          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-center justify-between py-2 border-b border-border/30 last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{activity.action}</p>
                  <p className="text-xs text-muted-foreground">{activity.detail} • {activity.time}</p>
                </div>
                <span className="text-sm font-semibold text-primary">+{activity.points} pts</span>
              </div>
            ))}
          </div>
        </div>


        {/* Achievements */}
        <div className="animate-slide-up" style={{ animationDelay: "500ms" }}>
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-muted-foreground" />
            <h2 className="font-display text-lg font-semibold text-foreground">All Achievements</h2>
          </div>


          <div className="bg-card rounded-2xl border border-border p-6">
            <div className="grid grid-cols-5 gap-4">
              {allBadges.map((badge) => (
                <AchievementBadge 
                  key={badge} 
                  name={badge} 
                  unlocked={learner.badges.includes(badge)}
                  size="sm"
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};


export default ProfilePage;
