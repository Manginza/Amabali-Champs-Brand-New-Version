import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { schools } from "@/data/schools";
import { format } from "date-fns";
import {
  ArrowLeft,
  BookOpen,
  PenLine,
  Star,
  Calendar,
  ChevronRight,
  User,
  GraduationCap,
  Building2,
} from "lucide-react";


interface Review {
  id: string;
  review_title: string;
  book_name: string;
  star_rating: number;
  created_at: string;
  reward_status: "pending" | "rewarded" | "revoked";
}


export default function LearnerDashboardPage() {
  const { user, profile, role, loading } = useAuth();
  const { toast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);


  useEffect(() => {
    if (user) {
      fetchUserReviews();
    }
  }, [user]);


  const fetchUserReviews = async () => {
    try {
      const { data, error } = await supabase
        .from("book_reviews")
        .select("id, review_title, book_name, star_rating, created_at, reward_status")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });


      if (error) throw error;
      setReviews((data || []).map(r => ({
        ...r,
        reward_status: (r.reward_status || "pending") as Review["reward_status"]
      })));
    } catch (error: any) {
      toast({
        title: "Error loading reviews",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoadingReviews(false);
    }
  };


  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };


  const getSchoolName = (schoolId: string | null) => {
    if (!schoolId) return "Not set";
    return schools.find(s => s.id === schoolId)?.name || schoolId;
  };


  // Build reward history from reviews
  const rewardHistory = reviews.map(review => ({
    id: review.id,
    type: review.reward_status === "revoked" ? "penalty" as const : "reward" as const,
    amount: 2,
    reason: `Review: "${review.review_title}"`,
    date: format(new Date(review.created_at), "MMM d, yyyy"),
    status: review.reward_status,
  }));


  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }


  if (!user || role !== "student") {
    return <Navigate to="/student-auth" replace />;
  }


  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 md:pt-20">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>


        <div className="grid lg:grid-cols-3 gap-6">
          {/* Profile Card */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-border shadow-soft">
              <CardContent className="pt-6">
                <div className="text-center">
                  <Avatar className="w-20 h-20 mx-auto mb-4">
                    <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-white text-2xl">
                      {getInitials(profile?.full_name || "S")}
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-display font-bold text-foreground">
                    {profile?.full_name || "Student"}
                  </h2>
                  <p className="text-sm text-muted-foreground">{profile?.email}</p>
                  
                  <div className="flex flex-wrap justify-center gap-2 mt-4">
                    <Badge variant="secondary" className="gap-1">
                      <Building2 className="w-3 h-3" />
                      {getSchoolName(profile?.school_id || null)}
                    </Badge>
                    {profile?.grade && (
                      <Badge variant="outline" className="gap-1">
                        <GraduationCap className="w-3 h-3" />
                        {profile.grade}
                      </Badge>
                    )}
                  </div>
                </div>


                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="text-center p-4 bg-muted/50 rounded-xl">
                    <BookOpen className="w-6 h-6 text-primary mx-auto mb-2" />
                    <p className="text-2xl font-bold text-foreground">{reviews.length}</p>
                    <p className="text-xs text-muted-foreground">Reviews Written</p>
                  </div>
                  <div className="text-center p-4 bg-muted/50 rounded-xl">
                    <Star className="w-6 h-6 text-warning mx-auto mb-2" />
                    <p className="text-2xl font-bold text-foreground">
                      {reviews.filter(r => r.reward_status === "rewarded").length}
                    </p>
                    <p className="text-xs text-muted-foreground">Approved</p>
                  </div>
                </div>


                <div className="mt-6">
                  <Link to="/book-review">
                    <Button className="w-full">
                      <PenLine className="w-4 h-4 mr-2" />
                      Write New Review
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>


            {/* Wallet */}
            <LearnerWallet 
              balance={profile?.balance || 0} 
              rewardHistory={rewardHistory}
            />
          </div>


          {/* Reviews List */}
          <div className="lg:col-span-2">
            <Card className="border-border shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  My Reviews
                </CardTitle>
              </CardHeader>
              <CardContent>
                {loadingReviews ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full mx-auto" />
                  </div>
                ) : reviews.length === 0 ? (
                  <div className="text-center py-12">
                    <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No reviews yet</h3>
                    <p className="text-muted-foreground mb-6">
                      Start writing book reviews to earn R2 per approved review!
                    </p>
                    <Link to="/book-review">
                      <Button>
                        <PenLine className="w-4 h-4 mr-2" />
                        Write Your First Review
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <div
                        key={review.id}
                        className="flex items-center justify-between p-4 rounded-xl bg-muted/30 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-secondary to-warning flex items-center justify-center">
                            <BookOpen className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground">
                              {review.review_title}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {review.book_name}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <ReviewStatusBadge status={review.reward_status} />
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {format(new Date(review.created_at), "MMM d, yyyy")}
                              </span>
                            </div>
                          </div>
                        </div>
                        <Link to={`/reviews-feed`}>
                          <Button variant="ghost" size="icon">
                            <ChevronRight className="w-5 h-5" />
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
import { useLocation } from "react-router-dom";
import { useEffect } from "react";


const NotFound = () => {
  const location = useLocation();


  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);


  return (
    <div className="flex min-h-screen items-center justify-center bg-muted">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
