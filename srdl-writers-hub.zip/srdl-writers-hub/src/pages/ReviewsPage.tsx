export default ReviewsPage;


import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getSessionId } from "@/lib/sessionStorage";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { SEOHead } from "@/components/SEOHead";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { schools } from "@/data/schools";
import { VolunteerRatingSlider } from "@/components/VolunteerRatingSlider";
import { ExternalRating } from "@/components/ExternalRating";
import {
  Search,
  BookText,
  User,
  School,
  GraduationCap,
  Calendar,
  MessageCircle,
  ChevronDown,
  ChevronUp,
  Send,
  Loader2,
} from "lucide-react";
import { format } from "date-fns";


interface Story {
  id: string;
  title: string;
  author_name: string;
  full_story: string | null;
  category: string | null;
  school_id: string | null;
  grade: string | null;
  word_count: number | null;
  created_at: string;
  status: string;
  avg_external_rating: number | null;
  external_rating_count: number | null;
}


interface StoryComment {
  id: string;
  story_id: string;
  content: string;
  author_name: string;
  rating: number | null;
  user_id: string | null;
  is_volunteer: boolean;
  session_id: string | null;
  created_at: string;
}


export default function StoriesFeedPage() {
