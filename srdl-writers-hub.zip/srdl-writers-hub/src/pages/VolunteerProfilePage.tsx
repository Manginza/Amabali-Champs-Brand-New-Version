export default function VolunteerProfilePage() {
  const navigate = useNavigate();
  const { user, profile, role, signOut, loading } = useAuth();
  const [feedbackHistory, setFeedbackHistory] = useState<FeedbackHistory[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);


  useEffect(() => {
    if (!loading && !user) {
      navigate("/volunteer-auth");
    }
  }, [user, loading, navigate]);


  useEffect(() => {
    if (user) {
      fetchFeedbackHistory();
    }
  }, [user]);


  const fetchFeedbackHistory = async () => {
    try {
      const { data: feedbackData, error: feedbackError } = await supabase
        .from("volunteer_feedback")
        .select("id, feedback_content, created_at, review_id")
        .eq("volunteer_id", user?.id)
        .order("created_at", { ascending: false });


      if (feedbackError) throw feedbackError;


      // Fetch related review info
      const reviewIds = feedbackData?.map(f => f.review_id) || [];
      if (reviewIds.length > 0) {
        const { data: reviews } = await supabase
          .from("book_reviews")
          .select("id, review_title, book_name, student_name")
          .in("id", reviewIds);


        const reviewMap: Record<string, any> = {};
        reviews?.forEach(r => {
          reviewMap[r.id] = r;
        });


        const enrichedFeedback = feedbackData?.map(f => ({
          ...f,
          review_title: reviewMap[f.review_id]?.review_title || "Unknown Review",
          book_name: reviewMap[f.review_id]?.book_name || "Unknown Book",
          student_name: reviewMap[f.review_id]?.student_name || "Unknown Student",
        })) || [];


        setFeedbackHistory(enrichedFeedback);
      }
    } catch (error) {
      console.error("Error fetching feedback history:", error);
    } finally {
      setLoadingHistory(false);
    }
  };


  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };


  const getInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);
  };


  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }


  if (!user || !profile) {
    return null;
  }


  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 md:pt-20">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <Link
          to="/reviews-feed"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Reviews
        </Link>


        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Profile Card */}
          <Card className="lg:col-span-1">
            <CardHeader className="text-center">
              <Avatar className="w-24 h-24 mx-auto mb-4">
                <AvatarFallback className="bg-gradient-to-br from-primary to-secondary text-white text-2xl">
                  {getInitials(profile.full_name)}
                </AvatarFallback>
              </Avatar>
              <CardTitle className="text-2xl">{profile.full_name}</CardTitle>
              <Badge className="mx-auto mt-2 bg-primary/20 text-primary">
                Volunteer
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Building2 className="w-5 h-5 text-primary" />
                <span>{profile.company_name || "Not specified"}</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Briefcase className="w-5 h-5 text-primary" />
                <span>{profile.job_title || "Not specified"}</span>
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Mail className="w-5 h-5 text-primary" />
                <span>{profile.email}</span>
              </div>
              {profile.phone_number && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Phone className="w-5 h-5 text-primary" />
                  <span>{profile.phone_number}</span>
                </div>
              )}


              {profile.bio && (
                <div className="pt-4 border-t border-border">
                  <h4 className="font-semibold text-foreground mb-2">About</h4>
                  <p className="text-muted-foreground text-sm">{profile.bio}</p>
                </div>
              )}


              <div className="pt-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleSignOut}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </Button>
              </div>
            </CardContent>
          </Card>


          {/* Feedback History */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle>Feedback History</CardTitle>
                  <CardDescription>
                    All feedback you've provided to students
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loadingHistory ? (
                <div className="text-center py-8">
                  <div className="animate-spin w-6 h-6 border-4 border-primary border-t-transparent rounded-full mx-auto" />
                </div>
              ) : feedbackHistory.length === 0 ? (
                <div className="text-center py-8">
                  <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No feedback yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start helping students by reviewing their book reviews.
                  </p>
                  <Link to="/reviews-feed">
                    <Button>
                      <BookOpen className="w-4 h-4 mr-2" />
                      View Student Reviews
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {feedbackHistory.map((feedback) => (
                    <div
                      key={feedback.id}
                      className="p-4 rounded-xl border border-border bg-muted/30"
                    >
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div>
                          <h4 className="font-semibold text-foreground">
                            {feedback.review_title}
                          </h4>
                          <p className="text-sm text-primary">
                            Book: {feedback.book_name} • By: {feedback.student_name}
                          </p>
                        </div>
                        <span className="text-xs text-muted-foreground flex items-center gap-1 whitespace-nowrap">
                          <Calendar className="w-3 h-3" />
                          {format(new Date(feedback.created_at), "MMM d, yyyy")}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {feedback.feedback_content}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}


#root {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;
  text-align: center;
}


.logo {
  height: 6em;
  padding: 1.5em;
  will-change: filter;
  transition: filter 300ms;
}
.logo:hover {
  filter: drop-shadow(0 0 2em #646cffaa);
}
.logo.react:hover {
  filter: drop-shadow(0 0 2em #61dafbaa);
}


@keyframes logo-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}


@media (prefers-reduced-motion: no-preference) {
  a:nth-of-type(2) .logo {
    animation: logo-spin infinite 20s linear;
  }
}


.card {
  padding: 2em;
}


.read-the-docs {
  color: #888;
}


import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LearnerProvider } from "@/contexts/LearnerContext";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import CreateStoryPage from "./pages/CreateStoryPage";
import StoriesFeedPage from "./pages/StoriesFeedPage";
import LeaderboardPage from "./pages/LeaderboardPage";
import ReviewsPage from "./pages/ReviewsPage";
import ProfilePage from "./pages/ProfilePage";
import VolunteerAuthPage from "./pages/VolunteerAuthPage";
import BookReviewPage from "./pages/BookReviewPage";
import ReviewsFeedPage from "./pages/ReviewsFeedPage";
import ReviewDetailPage from "./pages/ReviewDetailPage";
import VolunteerProfilePage from "./pages/VolunteerProfilePage";
import VolunteerDashboardPage from "./pages/VolunteerDashboardPage";
import StudentAuthPage from "./pages/StudentAuthPage";
import AdminAuthPage from "./pages/AdminAuthPage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import LearnerDashboardPage from "./pages/LearnerDashboardPage";
import ReadingGymPage from "./pages/ReadingGymPage";
import AdminReadingGymPage from "./pages/AdminReadingGymPage";
import NotFound from "./pages/NotFound";


const queryClient = new QueryClient();


const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <LearnerProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/create" element={<CreateStoryPage />} />
              <Route path="/stories" element={<StoriesFeedPage />} />
              <Route path="/leaderboard" element={<LeaderboardPage />} />
              <Route path="/reviews" element={<ReviewsPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/volunteer-auth" element={<VolunteerAuthPage />} />
              <Route path="/book-review" element={<BookReviewPage />} />
              <Route path="/reviews-feed" element={<ReviewsFeedPage />} />
              <Route path="/reviews/:bookSlug/:studentSlug" element={<ReviewDetailPage />} />
              <Route path="/volunteer-profile" element={<VolunteerProfilePage />} />
              <Route path="/volunteer-dashboard" element={<VolunteerDashboardPage />} />
              <Route path="/student-auth" element={<StudentAuthPage />} />
              <Route path="/admin-login" element={<AdminAuthPage />} />
              <Route path="/admin" element={<AdminDashboardPage />} />
              <Route path="/learner-dashboard" element={<LearnerDashboardPage />} />
              <Route path="/reading-gym" element={<ReadingGymPage />} />
              <Route path="/admin/reading-gym" element={<AdminReadingGymPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </LearnerProvider>
    </AuthProvider>
  </QueryClientProvider>
);


export default App;
