export default ReadingLevelPage;
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { 
  ArrowLeft, 
  Sparkles, 
  FileText, 
  Zap,
  ChevronRight,
  BookOpen,
  Star,
  Users
} from "lucide-react";
import { cn } from "@/lib/utils";


const readingZones = [
  {
    id: "entry",
    title: "Entry Level Reader",
    ageRange: "Ages 5-7",
    description: "Short, engaging stories with large typography and simple vocabulary. Perfect for building reading confidence!",
    features: ["100-200 words", "Pronunciation guides", "Progress tracking"],
    icon: Sparkles,
    gradient: "bg-card-teal",
    buttonGradient: "bg-gradient-teal",
    iconColor: "text-primary",
    storiesCount: 24,
  },
  {
    id: "intermediate",
    title: "Intermediate Reader",
    ageRange: "Ages 8-12",
    description: "Medium-length stories with comprehension questions and vocabulary building activities.",
    features: ["300-500 words", "Comprehension quizzes", "Flashcards"],
    icon: FileText,
    gradient: "bg-card-orange",
    buttonGradient: "bg-gradient-orange",
    iconColor: "text-secondary",
    storiesCount: 36,
  },
  {
    id: "advanced",
    title: "Advanced Reader",
    ageRange: "Ages 13+",
    description: "Complex narratives with literary analysis and deep comprehension challenges for master readers.",
    features: ["500+ words", "Analysis discussions", "Challenge lists"],
    icon: Zap,
    gradient: "bg-card-purple",
    buttonGradient: "bg-gradient-purple",
    iconColor: "text-accent",
    storiesCount: 28,
  },
];


const ReadingPage = () => {
  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Header */}
        <div className="text-center mb-10 animate-slide-up">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-teal flex items-center justify-center shadow-glow-teal">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl md:text-5xl font-display font-bold text-foreground mb-3">
            Reading <span className="text-gradient-teal">Gym</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Choose your reading level and start your journey to becoming a master reader!
          </p>
        </div>


        {/* Reading Zones */}
        <div className="space-y-6 mb-10">
          {readingZones.map((zone, index) => (
            <div
              key={zone.id}
              className={cn(
                "group rounded-2xl border border-border overflow-hidden transition-all duration-300 card-hover animate-slide-up",
                zone.gradient
              )}
              style={{ animationDelay: `${100 + index * 100}ms` }}
            >
              <div className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center gap-6">
                  {/* Icon & Info */}
                  <div className="flex-1">
                    <div className="flex items-start gap-4">
                      <div className={cn(
                        "w-14 h-14 rounded-xl flex items-center justify-center shrink-0",
                        zone.buttonGradient
                      )}>
                        <zone.icon className="w-7 h-7 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h2 className="font-display text-xl md:text-2xl font-bold text-foreground">
                            {zone.title}
                          </h2>
                          <span className="text-xs px-2 py-1 rounded-full bg-background/50 text-muted-foreground font-medium">
                            {zone.ageRange}
                          </span>
                        </div>
                        <p className="text-foreground/80 mb-4">
                          {zone.description}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {zone.features.map((feature) => (
                            <span
                              key={feature}
                              className="text-xs px-3 py-1.5 rounded-full bg-background/60 text-foreground/70 font-medium"
                            >
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>


                  {/* Stats & CTA */}
                  <div className="flex items-center gap-4 md:flex-col md:items-end">
                    <div className="flex items-center gap-2 text-foreground/70">
                      <Users className="w-4 h-4" />
                      <span className="text-sm">{zone.storiesCount} stories</span>
                    </div>
                    <Link to={`/reading/${zone.id}`}>
                      <Button 
                        className={cn(
                          "gap-2 font-semibold text-white",
                          zone.buttonGradient,
                          "hover:opacity-90 transition-opacity"
                        )}
                      >
                        Start Reading
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>


        {/* Daily Challenge Banner */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-soft mb-8 animate-slide-up" style={{ animationDelay: "400ms" }}>
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-orange flex items-center justify-center shadow-glow-orange animate-bounce-soft">
              <Star className="w-8 h-8 text-white" />
            </div>
            <div className="text-center sm:text-left flex-1">
              <h3 className="font-display font-bold text-lg text-foreground">
                Daily Reading Challenge
              </h3>
              <p className="text-muted-foreground">
                Read 3 stories today to earn bonus points and keep your streak alive!
              </p>
            </div>
            <Button variant="outline" className="border-secondary text-secondary hover:bg-secondary/10">
              View Challenge
            </Button>
          </div>
        </div>


        {/* Back to Dashboard */}
        <div className="text-center animate-slide-up" style={{ animationDelay: "500ms" }}>
          <Link to="/">
            <Button variant="ghost" className="gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
};


export default ReadingPage;
