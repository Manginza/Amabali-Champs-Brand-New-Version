import { useAuth } from "@/contexts/AuthContext";
import { useLearner } from "@/contexts/LearnerContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { schools, grades } from "@/data/schools";
import { getSessionId } from "@/lib/sessionStorage";
import { StoryLeaderboard } from "@/components/StoryLeaderboard";
import { SEOHead } from "@/components/SEOHead";
import { 
  ArrowLeft,
  PenTool, 
  Save,
  Send,
  Trophy,
  CheckCircle2,
  School,
  User,
  Sparkles,
  Lightbulb
} from "lucide-react";


const categories = [
  "Fantasy",
  "Adventure", 
  "School Life",
  "Animals",
  "Science Fiction",
  "Mystery",
  "Real Life",
  "Nature",
];


const writingPrompts = [
  {
    title: "The Magic Door",
    starter: "One day, I discovered a hidden door in my school that led to...",
    category: "Fantasy"
  },
  {
    title: "The Talking Animal",
    starter: "I couldn't believe my ears when my pet suddenly said...",
    category: "Animals"
  },
  {
    title: "The Time Machine",
    starter: "When I pressed the button on the strange machine, I found myself in the year...",
    category: "Science Fiction"
  },
  {
    title: "The Missing Treasure",
    starter: "The old map I found in my grandmother's attic showed a treasure hidden at...",
    category: "Adventure"
  },
  {
    title: "The New Kid",
    starter: "There was something very unusual about the new student who joined our class today...",
    category: "School Life"
  },
  {
    title: "The Secret Garden",
    starter: "Behind the old wall covered in vines, I discovered a garden where...",
    category: "Nature"
  },
  {
    title: "The Strange Package",
    starter: "When I opened the mysterious package left on our doorstep, I found...",
    category: "Mystery"
  },
  {
    title: "My Superpower",
    starter: "I woke up one morning and realized I could...",
    category: "Fantasy"
  },
];


export default function CreateStoryPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { learner, updateLearner, addBadge, addPoints } = useLearner();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);


  // Simplified form data
  const [title, setTitle] = useState("");
  const [authorName, setAuthorName] = useState(learner.name || "");
  const [storyContent, setStoryContent] = useState("");
  const [category, setCategory] = useState("");
  const [schoolId, setSchoolId] = useState(learner.schoolId || "");
  const [grade, setGrade] = useState(learner.grade || "");


  const getWordCount = () => {
    return storyContent.trim().split(/\s+/).filter(Boolean).length;
  };


  const handleSaveDraft = async () => {
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please add a title before saving.",
        variant: "destructive",
      });
      return;
    }


    setLoading(true);
    try {
      const sessionId = getSessionId();


      const { error } = await supabase.from("stories").insert({
        user_id: user?.id || null,
        session_id: sessionId,
        is_registered_user: !!user,
        author_name: authorName,
        school_id: schoolId || null,
        grade: grade || null,
        title,
        full_story: storyContent || null,
        category: category || null,
        word_count: getWordCount(),
        status: "draft",
      });


      if (error) throw error;


      toast({
        title: "Draft Saved!",
        description: "Your story has been saved. You can continue later.",
      });
    } catch (error: any) {
      toast({
        title: "Save failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    }
    setLoading(false);
  };


  const handlePublish = async () => {
    const wordCount = getWordCount();
    if (wordCount < 50) {
      toast({
        title: "Story too short",
        description: "Please write at least 50 words before publishing.",
        variant: "destructive",
      });
      return;
    }


    if (!authorName.trim()) {
      toast({
        title: "Author name required",
        description: "Please enter your name.",
        variant: "destructive",
      });
      return;
    }


    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your story.",
        variant: "destructive",
      });
      return;
    }


    setLoading(true);
    try {
      const sessionId = getSessionId();


      const { error } = await supabase.from("stories").insert({
        user_id: user?.id || null,
        session_id: sessionId,
        is_registered_user: !!user,
        author_name: authorName,
        school_id: schoolId || null,
        grade: grade || null,
        title,
        full_story: storyContent,
        category: category || null,
        word_count: wordCount,
        status: "published",
      });


      if (error) throw error;


      // Update local learner stats
      updateLearner({ storiesWritten: learner.storiesWritten + 1 });
      addPoints(25);


      if (learner.storiesWritten === 0) {
        addBadge("First Story Written");
      }


      if (wordCount >= 100 && !learner.badges.includes("100 Words Written")) {
        addBadge("100 Words Written");
        toast({
          title: "Badge Unlocked!",
          description: "You earned '100 Words Written'!",
        });
      }


      setSubmitted(true);
      toast({
        title: "Story Published!",
        description: "Your story is now in the community gallery!",
      });
    } catch (error: any) {
      toast({
        title: "Publish failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    }
    setLoading(false);
  };


  const resetForm = () => {
    setTitle("");
    setAuthorName(learner.name || "");
    setStoryContent("");
    setCategory("");
    setSubmitted(false);
  };


  if (submitted) {
    return (
      <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-1 flex items-center justify-center">
          <div className="max-w-lg mx-auto text-center">
            <div className="w-20 h-20 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-success" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground mb-4">
              Story Published!
            </h1>
            <p className="text-muted-foreground mb-2">
              Your story "{title}" is now live in the community gallery.
            </p>
            <p className="text-success font-bold text-xl mb-8">
              You earned 25 points!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={resetForm} variant="outline">
                Write Another Story
              </Button>
              <Button onClick={() => navigate("/leaderboard")}>
                View Leaderboard
              </Button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <SEOHead
        title="Create Your Story - SRDL Writers Hub"
        description="Write and share your creative stories. Share your imagination with the community!"
        keywords="creative writing, student stories, story contest, writing for kids"
      />
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-3xl">
        {/* Header */}
        <div className="mb-8 animate-slide-up">
          <Link to="/">
            <Button variant="ghost" className="gap-2 mb-4 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-purple flex items-center justify-center shadow-glow-purple">
              <PenTool className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                Create Your <span className="text-gradient-purple">Story</span>
              </h1>
              <p className="text-muted-foreground">
                Let your imagination flow!
              </p>
            </div>
          </div>
        </div>


        {/* Tabs */}
        <Tabs defaultValue="write" className="animate-slide-up" style={{ animationDelay: "50ms" }}>
          <TabsList className="mb-6">
            <TabsTrigger value="write" className="gap-2">
              <PenTool className="w-4 h-4" />
              Write Story
            </TabsTrigger>
            <TabsTrigger value="leaderboard" className="gap-2">
              <Trophy className="w-4 h-4" />
              Story Rankings
            </TabsTrigger>
          </TabsList>


          <TabsContent value="write">
            <div className="bg-card rounded-2xl p-6 md:p-8 border border-border shadow-soft">
              {/* Header Icon */}
              <div className="text-center mb-8">
                <div className="w-16 h-16 rounded-full bg-gradient-purple flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-2xl font-display font-bold text-foreground mb-2">
                  Write Your Story
                </h2>
                <p className="text-muted-foreground">
                  Share your imagination with the world!
                </p>
              </div>


              <div className="space-y-6">
                {/* Author & School Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-xl">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <User className="w-4 h-4 text-accent" />
                      Author Name
                    </Label>
                    <Input
                      placeholder="Your name or pen name..."
                      value={authorName}
                      onChange={(e) => setAuthorName(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <School className="w-4 h-4 text-accent" />
                      School (Optional)
                    </Label>
                    <Select value={schoolId} onValueChange={setSchoolId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your school" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {schools.map((school) => (
                          <SelectItem key={school.id} value={school.id}>
                            {school.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Grade (Optional)</Label>
                    <Select value={grade} onValueChange={setGrade}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your grade" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {grades.map((g) => (
                          <SelectItem key={g.value} value={g.value}>
                            {g.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Category (Optional)</Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a category" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat.toLowerCase()}>
                            {cat}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>


                {/* Writing Prompts */}
                <div className="space-y-3">
                  <Label className="flex items-center gap-2 text-foreground">
                    <Lightbulb className="w-4 h-4 text-warning" />
                    Need Inspiration? Try a Story Starter!
                  </Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {writingPrompts.map((prompt, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => {
                          setTitle(prompt.title);
                          setStoryContent(prompt.starter + " ");
                          setCategory(prompt.category.toLowerCase());
                        }}
                        className="p-3 text-left rounded-lg border border-border bg-muted/30 hover:bg-accent/10 hover:border-accent transition-all group"
                      >
                        <p className="text-sm font-medium text-foreground group-hover:text-accent">
                          {prompt.title}
                        </p>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                          {prompt.starter}
                        </p>
                      </button>
                    ))}
                  </div>
                </div>


                {/* Story Title */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-foreground">
                    <Sparkles className="w-4 h-4 text-accent" />
                    Story Title
                  </Label>
                  <Input
                    placeholder="Give your story an exciting title..."
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="text-lg font-display"
                  />
                </div>


                {/* Story Content */}
                <div className="space-y-2">
                  <Label className="flex items-center gap-2 text-foreground">
                    <PenTool className="w-4 h-4 text-accent" />
                    Your Story
                  </Label>
                  <Textarea
                    placeholder="Once upon a time... Write your story here! Let your imagination run wild. Describe your characters, the setting, the adventure, and how it all ends!"
                    value={storyContent}
                    onChange={(e) => setStoryContent(e.target.value)}
                    rows={12}
                    className="resize-none"
                  />
                  <p className="text-xs text-muted-foreground">
                    Write at least 50 words to publish your story. There are no wrong answers - just let your creativity flow!
                  </p>
                </div>


                {/* Word Count */}
                <div className="text-center">
                  <span className={`text-sm font-medium ${getWordCount() >= 50 ? "text-success" : "text-muted-foreground"}`}>
                    {getWordCount()} words {getWordCount() < 50 && `(${50 - getWordCount()} more to publish)`}
                  </span>
                </div>


                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    variant="outline"
                    onClick={handleSaveDraft}
                    disabled={loading || !title.trim()}
                    className="gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Save Draft
                  </Button>
                  
                  <Button
                    onClick={handlePublish}
                    disabled={loading || getWordCount() < 50 || !title.trim() || !authorName.trim()}
                    className="gap-2 bg-gradient-purple hover:opacity-90 text-white flex-1"
                  >
                    <Send className="w-4 h-4" />
                    {loading ? "Publishing..." : "Publish Story"}
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>


          <TabsContent value="leaderboard">
            <StoryLeaderboard />
          </TabsContent>
        </Tabs>
      </main>


      <Footer />
    </div>
  );
}
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SchoolSelector } from "@/components/SchoolSelector";
import { ReadingStreakCard } from "@/components/ReadingStreakCard";
import { QuickActionsGrid } from "@/components/QuickActionsGrid";
import { AchievementBadge } from "@/components/AchievementBadge";
import { useLearner } from "@/contexts/LearnerContext";
import { useAuth } from "@/contexts/AuthContext";
