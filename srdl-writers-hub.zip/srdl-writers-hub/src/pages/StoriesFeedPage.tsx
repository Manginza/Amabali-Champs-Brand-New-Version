export default function StoriesFeedPage() {
  const { user, role, profile } = useAuth();
  const { toast } = useToast();
  const [stories, setStories] = useState<Story[]>([]);
  const [comments, setComments] = useState<Record<string, StoryComment[]>>({});
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedStories, setExpandedStories] = useState<Set<string>>(new Set());
  const [newComments, setNewComments] = useState<Record<string, string>>({});
  const [submittingFeedback, setSubmittingFeedback] = useState<string | null>(null);
  const [submittingComment, setSubmittingComment] = useState<string | null>(null);


  useEffect(() => {
    fetchStories();
  }, []);


  const fetchStories = async () => {
    setLoading(true);
    try {
      const { data: storiesData, error: storiesError } = await supabase
        .from("stories")
        .select("*")
        .eq("status", "published")
        .order("created_at", { ascending: false });


      if (storiesError) throw storiesError;
      setStories(storiesData || []);


      // Fetch comments for all stories
      if (storiesData && storiesData.length > 0) {
        const storyIds = storiesData.map((s) => s.id);
        const { data: commentsData, error: commentsError } = await supabase
          .from("story_comments")
          .select("*")
          .in("story_id", storyIds)
          .order("created_at", { ascending: false });


        if (commentsError) throw commentsError;


        // Group comments by story_id
        const groupedComments: Record<string, StoryComment[]> = {};
        (commentsData || []).forEach((comment) => {
          if (!groupedComments[comment.story_id]) {
            groupedComments[comment.story_id] = [];
          }
          groupedComments[comment.story_id].push(comment);
        });
        setComments(groupedComments);
      }
    } catch (error: any) {
      toast({
        title: "Error loading stories",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    }
    setLoading(false);
  };


  const getSchoolName = (schoolId: string | null) => {
    if (!schoolId) return "Unknown School";
    const school = schools.find((s) => s.id === schoolId);
    return school?.name || schoolId;
  };


  const toggleExpand = (storyId: string) => {
    const newExpanded = new Set(expandedStories);
    if (newExpanded.has(storyId)) {
      newExpanded.delete(storyId);
    } else {
      newExpanded.add(storyId);
    }
    setExpandedStories(newExpanded);
  };


  const handleSubmitComment = async (storyId: string) => {
    const content = newComments[storyId]?.trim();
    if (!content) return;


    setSubmittingComment(storyId);
    try {
      const authorName = profile?.full_name || "Anonymous";
      const isVolunteer = role === "volunteer";


      const { data, error } = await supabase.from("story_comments").insert({
        story_id: storyId,
        content,
        author_name: authorName,
        user_id: user?.id || null,
        is_volunteer: isVolunteer,
        session_id: user ? null : getSessionId(),
      }).select().single();


      if (error) throw error;


      // Add the new comment to the local state
      setComments((prev) => ({
        ...prev,
        [storyId]: [data, ...(prev[storyId] || [])],
      }));


      toast({
        title: "Comment Added",
        description: "Your comment has been posted!",
      });
      setNewComments((prev) => ({ ...prev, [storyId]: "" }));
    } catch (error: any) {
      toast({
        title: "Error posting comment",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    }
    setSubmittingComment(null);
  };


  const handleVolunteerFeedback = async (storyId: string, rating: number, feedback: string) => {
    if (!feedback.trim()) {
      toast({
        title: "Feedback required",
        description: "Please enter your motivational feedback.",
        variant: "destructive",
      });
      return;
    }


    setSubmittingFeedback(storyId);
    try {
      const authorName = profile?.full_name || "Volunteer";


      const { data, error } = await supabase.from("story_comments").insert({
        story_id: storyId,
        content: feedback,
        author_name: authorName,
        user_id: user?.id || null,
        is_volunteer: true,
        rating: rating,
        session_id: null,
      }).select().single();


      if (error) throw error;


      // Add the new feedback to the local state
      setComments((prev) => ({
        ...prev,
        [storyId]: [data, ...(prev[storyId] || [])],
      }));


      toast({
        title: "Feedback Submitted",
        description: `Rating: ${rating}% - Thank you for your feedback!`,
      });
    } catch (error: any) {
      toast({
        title: "Error submitting feedback",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    }
    setSubmittingFeedback(null);
  };


  const weightedScore = (avgRating: number | null, ratingCount: number | null) => {
    const r = avgRating || 0;
    const c = Math.min((ratingCount || 0) / 10, 1.0) * 5;
    return r * 0.7 + c * 0.3;
  };


  const filteredStories = stories
    .filter((story) => {
      const query = searchQuery.toLowerCase();
      return (
        story.title.toLowerCase().includes(query) ||
        story.author_name.toLowerCase().includes(query) ||
        (story.category && story.category.toLowerCase().includes(query))
      );
    })
    .sort((a, b) => {
      const scoreDiff = weightedScore(b.avg_external_rating, b.external_rating_count) - weightedScore(a.avg_external_rating, a.external_rating_count);
      if (scoreDiff !== 0) return scoreDiff;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });


  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <SEOHead
        title="Stories Feed - SRDL Writers Hub"
        description="Read and rate creative stories written by learners. Volunteers can provide feedback and ratings."
        keywords="student stories, creative writing, story feedback, volunteer reading"
      />
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-slide-up">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-gradient-purple flex items-center justify-center shadow-glow-purple">
              <BookText className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                Stories <span className="text-gradient-purple">Feed</span>
              </h1>
              <p className="text-muted-foreground">
                Read, rate, and engage with learner stories
              </p>
            </div>
          </div>


          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search stories by title, author, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>


        {/* Volunteer Info */}
        {role === "volunteer" && (
          <div className="mb-6 p-4 bg-primary/10 rounded-xl border border-primary/20">
            <p className="text-sm text-primary font-medium">
              As a volunteer, you can provide ratings and motivational feedback to help learners grow!
            </p>
          </div>
        )}


        {/* Stories List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredStories.length === 0 ? (
          <div className="text-center py-12">
            <BookText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">
              No Stories Yet
            </h3>
            <p className="text-muted-foreground mb-4">
              Be the first to share your story!
            </p>
            <Link to="/create">
              <Button>Create a Story</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredStories.map((story) => (
              <Card key={story.id} className="animate-slide-up">
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <CardTitle className="text-xl mb-2">{story.title}</CardTitle>
                      <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {story.author_name}
                        </span>
                        {story.school_id && (
                          <span className="flex items-center gap-1">
                            <School className="w-4 h-4" />
                            {getSchoolName(story.school_id)}
                          </span>
                        )}
                        {story.grade && (
                          <span className="flex items-center gap-1">
                            <GraduationCap className="w-4 h-4" />
                            {story.grade}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(story.created_at), "MMM d, yyyy")}
                        </span>
                      </div>
                    </div>
                    {story.category && (
                      <Badge variant="secondary">{story.category}</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Story Content */}
                  <div className="mb-4">
                    <div
                      className={`prose prose-sm max-w-none text-foreground ${
                        !expandedStories.has(story.id) ? "line-clamp-4" : ""
                      }`}
                    >
                      <p className="whitespace-pre-wrap">
                        {story.full_story || "No content available."}
                      </p>
                    </div>
                    {story.full_story && story.full_story.length > 300 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleExpand(story.id)}
                        className="mt-2 gap-1"
                      >
                        {expandedStories.has(story.id) ? (
                          <>
                            Show Less <ChevronUp className="w-4 h-4" />
                          </>
                        ) : (
                          <>
                            Read More <ChevronDown className="w-4 h-4" />
                          </>
                        )}
                      </Button>
                    )}
                  </div>


                  {/* Word Count */}
                  {story.word_count && (
                    <p className="text-sm text-muted-foreground mb-4">
                      {story.word_count} words
                    </p>
                  )}


                  {/* External Rating */}
                  <div className="mb-4 p-3 bg-muted/30 rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-2">Rate this story:</p>
                    <ExternalRating
                      targetType="story"
                      targetId={story.id}
                      currentRating={story.avg_external_rating || 0}
                      ratingCount={story.external_rating_count || 0}
                      onRatingSubmitted={fetchStories}
                    />
                  </div>


                  {/* Comment Section */}
                  <div className="border-t border-border pt-4">
                    <h4 className="font-medium mb-3 flex items-center gap-2">
                      <MessageCircle className="w-4 h-4" />
                      Comments & Feedback ({comments[story.id]?.length || 0})
                    </h4>


                    {/* Existing Comments */}
                    {comments[story.id] && comments[story.id].length > 0 && (
                      <div className="space-y-3 mb-4">
                        {comments[story.id].map((comment) => (
                          <div
                            key={comment.id}
                            className="p-3 bg-muted/20 rounded-lg border border-border"
                          >
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-medium text-sm text-foreground">
                                {comment.author_name}
                              </span>
                              {comment.is_volunteer && (
                                <Badge variant="secondary" className="text-xs">
                                  Volunteer
                                </Badge>
                              )}
                              <span className="text-xs text-muted-foreground">
                                {format(new Date(comment.created_at), "MMM d, yyyy")}
                              </span>
                              {comment.rating !== null && (
                                <Badge variant="outline" className="text-xs ml-auto">
                                  {comment.rating}% Rating
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-foreground">{comment.content}</p>
                          </div>
                        ))}
                      </div>
                    )}


                    {/* Comment Input */}
                    <div className="flex gap-2">
                      <Textarea
                        placeholder={
                          role === "volunteer"
                            ? "Share your feedback and motivation for the young writer..."
                            : "Leave a comment..."
                        }
                        value={newComments[story.id] || ""}
                        onChange={(e) =>
                          setNewComments((prev) => ({
                            ...prev,
                            [story.id]: e.target.value,
                          }))
                        }
                        className="flex-1 min-h-[80px]"
                      />
                    </div>


                    {/* Volunteer Rating */}
                    {role === "volunteer" ? (
                      <div className="mt-3">
                        <VolunteerRatingSlider
                          onSubmit={(rating, _feedback) => handleVolunteerFeedback(story.id, rating, _feedback)}
                          disabled={submittingFeedback === story.id}
                        />
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        onClick={() => handleSubmitComment(story.id)}
                        disabled={!newComments[story.id]?.trim() || submittingComment === story.id}
                        className="mt-3 gap-2"
                      >
                        {submittingComment === story.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Send className="w-4 h-4" />
                        )}
                        Post Comment
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>


      <Footer />
    </div>
  );
}
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { BookOpen, ArrowLeft, UserPlus, LogIn } from "lucide-react";
import { Link } from "react-router-dom";
import { schools, grades } from "@/data/schools";
import { z } from "zod";


const signupSchema = z.object({
  studentName: z.string().min(2, "Name must be at least 2 characters").max(100),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  schoolId: z.string().min(1, "Please select a school"),
  grade: z.string().min(1, "Please select a grade"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});


const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});


const StudentAuthPage = () => {
  const [isLogin, setIsLogin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    studentName: "",
    email: "",
    password: "",
    confirmPassword: "",
    schoolId: "",
    grade: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const navigate = useNavigate();
  const { toast } = useToast();
  const { signUp, signIn } = useAuth();


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setLoading(true);


    try {
      if (isLogin) {
        const result = loginSchema.safeParse({
          email: formData.email,
          password: formData.password,
        });


        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0] as string] = err.message;
            }
          });
          setErrors(fieldErrors);
          setLoading(false);
          return;
        }


        const { error } = await signIn(formData.email, formData.password);
        if (error) {
          toast({
            title: "Login failed",
            description: error.message,
            variant: "destructive",
          });
        } else {
          toast({
            title: "Welcome back!",
            description: "You're now logged in.",
          });
          navigate("/");
        }
      } else {
        const result = signupSchema.safeParse(formData);


        if (!result.success) {
          const fieldErrors: Record<string, string> = {};
          result.error.errors.forEach((err) => {
            if (err.path[0]) {
              fieldErrors[err.path[0] as string] = err.message;
            }
          });
          setErrors(fieldErrors);
          setLoading(false);
          return;
        }


        const { error } = await signUp(formData.email, formData.password, {
          full_name: formData.studentName,
          role: "student",
          school_id: formData.schoolId,
          grade: formData.grade,
        });


        if (error) {
          if (error.message.includes("already registered")) {
            toast({
              title: "Account exists",
              description: "This email is already registered. Please log in instead.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Sign up failed",
              description: error.message,
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "Welcome to ReadingQuest!",
            description: "Your account has been created. Start reading and earning!",
          });
          navigate("/");
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="min-h-screen bg-hero-gradient flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-teal flex items-center justify-center shadow-glow-teal">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-display">
            {isLogin ? "Welcome Back!" : "Join ReadingQuest"}
          </CardTitle>
          <CardDescription>
            {isLogin
              ? "Log in to continue your reading journey"
              : "Create your account and start earning R2 for every review!"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="studentName">Your Name or Alias</Label>
                  <Input
                    id="studentName"
                    placeholder="Enter your name or nickname"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    className={errors.studentName ? "border-destructive" : ""}
                  />
                  {errors.studentName && (
                    <p className="text-sm text-destructive">{errors.studentName}</p>
                  )}
                </div>


                <div className="space-y-2">
                  <Label htmlFor="schoolId">School</Label>
                  <Select
                    value={formData.schoolId}
                    onValueChange={(value) => setFormData({ ...formData, schoolId: value })}
                  >
                    <SelectTrigger className={errors.schoolId ? "border-destructive" : ""}>
                      <SelectValue placeholder="Select your school" />
                    </SelectTrigger>
                    <SelectContent>
                      {schools.map((school) => (
                        <SelectItem key={school.id} value={school.id}>
                          {school.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.schoolId && (
                    <p className="text-sm text-destructive">{errors.schoolId}</p>
                  )}
                </div>


                <div className="space-y-2">
                  <Label htmlFor="grade">Grade</Label>
                  <Select
                    value={formData.grade}
                    onValueChange={(value) => setFormData({ ...formData, grade: value })}
                  >
                    <SelectTrigger className={errors.grade ? "border-destructive" : ""}>
                      <SelectValue placeholder="Select your grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {grades.map((grade) => (
                        <SelectItem key={grade.value} value={grade.value}>
                          {grade.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.grade && (
                    <p className="text-sm text-destructive">{errors.grade}</p>
                  )}
                </div>
              </>
            )}


            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={errors.email ? "border-destructive" : ""}
              />
              {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
            </div>


            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className={errors.password ? "border-destructive" : ""}
              />
              {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
            </div>


            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className={errors.confirmPassword ? "border-destructive" : ""}
                />
                {errors.confirmPassword && (
                  <p className="text-sm text-destructive">{errors.confirmPassword}</p>
                )}
              </div>
            )}


            <Button type="submit" className="w-full gap-2" disabled={loading}>
              {loading ? (
                "Please wait..."
              ) : isLogin ? (
                <>
                  <LogIn className="w-4 h-4" />
                  Log In
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  Create Account
                </>
              )}
            </Button>
          </form>


          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin);
                setErrors({});
              }}
              className="text-sm text-primary hover:underline"
            >
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Log in"}
            </button>
          </div>


          <div className="mt-6 text-center">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};


export default StudentAuthPage;
