import { useAuth } from "@/contexts/AuthContext";
import { useLearner } from "@/contexts/LearnerContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { schools, grades, languages } from "@/data/schools";
import { getSessionId, hasSubmittedReview, recordSubmittedReview } from "@/lib/sessionStorage";
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle2, 
  User,
  School,
  MessageSquare,
  Save,
  Coins,
  PenLine,
  AlertCircle,
  Globe
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";


export default function BookReviewPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { learner } = useLearner();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);


  const [formData, setFormData] = useState({
    reviewTitle: "",
    bookName: "",
    bookAuthor: "",
    reviewContent: "",
    moralOfStory: "",
    starRating: 0,
    schoolId: learner.schoolId || "",
    grade: learner.grade || "",
    studentName: learner.name || "",
    language: "English",
  });


  const wordCount = formData.reviewContent.trim().split(/\s+/).filter(Boolean).length;
  const isValidLength = wordCount >= 60;


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();


    if (formData.starRating === 0) {
      toast({
        title: "Rating required",
        description: "Please select a star rating for the book.",
        variant: "destructive",
      });
      return;
    }


    if (wordCount < 60) {
      toast({
        title: "Review too short",
        description: "Please write at least 60 words for your review to earn R2.00.",
        variant: "destructive",
      });
      return;
    }


    if (!formData.studentName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter your name.",
        variant: "destructive",
      });
      return;
    }


    if (!formData.schoolId) {
      toast({
        title: "School required",
        description: "Please select your school.",
        variant: "destructive",
      });
      return;
    }


    // Check for duplicate submission (abuse prevention)
    if (hasSubmittedReview(formData.bookName, formData.studentName)) {
      toast({
        title: "Review already submitted",
        description: "You have already submitted a review for this book. Try reviewing a different book!",
        variant: "destructive",
      });
      return;
    }


    setLoading(true);


    try {
      const sessionId = getSessionId();
      const isRegistered = !!user;
      
      // Combine summary and moral of story for the review content
      const fullReview = formData.moralOfStory 
        ? `${formData.reviewContent}\n\nMoral of the Story: ${formData.moralOfStory}`
        : formData.reviewContent;


      const { error } = await supabase.from("book_reviews").insert({
        user_id: user?.id || null,
        session_id: sessionId,
        is_registered_user: isRegistered,
        review_title: formData.reviewTitle || `Review of ${formData.bookName}`,
        book_name: formData.bookName,
        review_content: fullReview,
        star_rating: formData.starRating,
        school_id: formData.schoolId,
        grade: formData.grade || "1",
        student_name: formData.studentName,
        language: formData.language,
      });


      if (error) throw error;


      // Record this submission to prevent duplicates
      recordSubmittedReview(formData.bookName, formData.studentName);


      setSubmitted(true);
      toast({
        title: "Review submitted! 🎉",
        description: "Your review is pending approval. You'll earn R2.00 once approved!",
      });
    } catch (error: any) {
      // Check for duplicate review constraint violation
      const isDuplicate = error?.code === "23505" || 
        error?.message?.includes("unique constraint") ||
        error?.message?.includes("duplicate") ||
        error?.message?.includes("unique_anon_review");
      
      if (isDuplicate) {
        // Also record locally to prevent repeated attempts
        recordSubmittedReview(formData.bookName, formData.studentName);
        toast({
          title: "Review already submitted",
          description: "You have already submitted a review for this book. Try reviewing a different book!",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Submission failed",
          description: "Something went wrong. Please try again later.",
          variant: "destructive",
        });
      }
    }


    setLoading(false);
  };


  if (submitted) {
    return (
      <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
        <Navbar />
        <div className="container mx-auto px-4 py-8 flex-1 flex items-center justify-center">
          <div className="max-w-lg mx-auto text-center">
            <div className="w-20 h-20 rounded-full bg-success/20 flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-success" />
            </div>
            <h1 className="text-3xl font-display font-bold text-foreground mb-4">
              Review Submitted!
            </h1>
            <p className="text-muted-foreground mb-2">
              Your book review has been submitted successfully.
            </p>
            <p className="text-success font-bold text-xl mb-2">
              Pending Approval 🎉
            </p>
            <p className="text-muted-foreground text-sm mb-8">
              You'll earn R2.00 once your review passes moderation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={() => {
                setSubmitted(false);
                setFormData({
                  reviewTitle: "",
                  bookName: "",
                  bookAuthor: "",
                  reviewContent: "",
                  moralOfStory: "",
                  starRating: 0,
                  schoolId: formData.schoolId,
                  grade: formData.grade,
                  studentName: formData.studentName,
                  language: formData.language,
                });
              }} variant="outline">
                Submit Another Review
              </Button>
              <Button onClick={() => navigate("/leaderboard")}>
                View Leaderboard
              </Button>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }


  return (
    <div className="min-h-screen bg-hero-gradient flex flex-col pb-20 md:pb-0 md:pt-20">
      <SEOHead
        title={`Write a Book Review - SRDL Writers Hub`}
        description="Share your thoughts on books and earn R2.00 per review. Students can write meaningful book reviews and improve their writing skills."
        keywords="book review, student review, earn money writing, book rating"
        ogType="article"
      />
      <Navbar />
      <div className="container mx-auto px-4 py-8 flex-1">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>


        {/* Guidelines Section */}
        <div className="max-w-2xl mx-auto">
          <ReviewGuidelines />


          {/* Incentive Banner */}
          <Alert className="mb-6 bg-success/10 border-success/30">
            <Coins className="h-4 w-4 text-success" />
            <AlertDescription className="text-success font-medium">
              Write a review of at least 60 words and earn R2.00. No registration required.
            </AlertDescription>
          </Alert>


          {/* Review Form - Purple gradient style */}
          <div className="bg-gradient-to-br from-[#4B0082] via-[#6B238E] to-[#4B0082] rounded-3xl p-8 shadow-2xl">
            {/* Header */}
            <div className="text-center mb-8">
              <h1 className="text-3xl md:text-4xl font-display font-bold text-white mb-2">
                Write a Review
              </h1>
              <p className="text-white/80">
                Share your thoughts and earn <span className="text-warning font-bold">R2.00</span> for your review of at least 60 words!
              </p>
            </div>


            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Review Title */}
              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2">
                  <PenLine className="w-4 h-4 text-warning" />
                  Review Title
                </Label>
                <Input
                  placeholder='e.g., "An Amazing Adventure"'
                  value={formData.reviewTitle}
                  onChange={(e) => setFormData({ ...formData, reviewTitle: e.target.value })}
                  className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning"
                />
              </div>


              {/* Book Title and Author */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-warning" />
                    Book Title
                  </Label>
                  <Input
                    placeholder="Enter the book title"
                    value={formData.bookName}
                    onChange={(e) => setFormData({ ...formData, bookName: e.target.value })}
                    className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning"
                    required
                  />
                </div>


                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <User className="w-4 h-4 text-warning" />
                    Book Author (Optional)
                  </Label>
                  <Input
                    placeholder="Enter the author's name"
                    value={formData.bookAuthor}
                    onChange={(e) => setFormData({ ...formData, bookAuthor: e.target.value })}
                    className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning"
                  />
                </div>
              </div>


              {/* Name and School - Side by Side */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <User className="w-4 h-4 text-warning" />
                    Your Name
                  </Label>
                  <Input
                    placeholder="Enter your full name"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning"
                    required
                  />
                </div>


                <div className="space-y-2">
                  <Label className="text-white flex items-center gap-2">
                    <School className="w-4 h-4 text-warning" />
                    School
                  </Label>
                  <Select
                    value={formData.schoolId}
                    onValueChange={(value) => setFormData({ ...formData, schoolId: value })}
                  >
                    <SelectTrigger className="bg-[#3a1a5c] border-[#5a2a7c] text-white focus:border-warning">
                      <SelectValue placeholder="Select your school" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#3a1a5c] border-[#5a2a7c]">
                      {schools.map((school) => (
                        <SelectItem key={school.id} value={school.id} className="text-white hover:bg-[#5a2a7c]">
                          {school.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>


              {/* Grade */}
              <div className="space-y-2">
                <Label className="text-white">Grade</Label>
                <Select
                  value={formData.grade}
                  onValueChange={(value) => setFormData({ ...formData, grade: value })}
                >
                  <SelectTrigger className="bg-[#3a1a5c] border-[#5a2a7c] text-white focus:border-warning">
                    <SelectValue placeholder="Select your grade" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#3a1a5c] border-[#5a2a7c]">
                    {grades.map((grade) => (
                      <SelectItem key={grade.value} value={grade.value} className="text-white hover:bg-[#5a2a7c]">
                        {grade.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>


              {/* Language */}
              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2">
                  <Globe className="w-4 h-4 text-warning" />
                  Language
                </Label>
                <Select
                  value={formData.language}
                  onValueChange={(value) => setFormData({ ...formData, language: value })}
                >
                  <SelectTrigger className="bg-[#3a1a5c] border-[#5a2a7c] text-white focus:border-warning">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#3a1a5c] border-[#5a2a7c]">
                    {languages.map((lang) => (
                      <SelectItem key={lang.value} value={lang.value} className="text-white hover:bg-[#5a2a7c]">
                        {lang.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>


              <div className="space-y-3">
                <Label className="text-white flex items-center gap-2">
                  Rate this book
                </Label>
                <div className="flex items-center gap-4">
                  <StarRating
                    rating={formData.starRating}
                    onRate={(rating) => setFormData({ ...formData, starRating: rating })}
                    size="lg"
                    interactive
                  />
                  {formData.starRating > 0 && (
                    <span className="text-white/70">
                      {formData.starRating} out of 5 stars
                    </span>
                  )}
                </div>
              </div>


              {/* Summary */}
              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-warning" />
                  Summary
                </Label>
                <Textarea
                  placeholder="What was the story about? What did you like?"
                  rows={5}
                  value={formData.reviewContent}
                  onChange={(e) => setFormData({ ...formData, reviewContent: e.target.value })}
                  className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning resize-none"
                  required
                />
                <div className="flex justify-end">
                  <span className={`text-sm ${isValidLength ? "text-success" : "text-warning"}`}>
                    {wordCount} / 60 words
                  </span>
                </div>
              </div>


              {/* Moral of the Story */}
              <div className="space-y-2">
                <Label className="text-white flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-warning" />
                  Moral of the Story (Optional)
                </Label>
                <Input
                  placeholder="What lesson did you learn?"
                  value={formData.moralOfStory}
                  onChange={(e) => setFormData({ ...formData, moralOfStory: e.target.value })}
                  className="bg-[#3a1a5c] border-[#5a2a7c] text-white placeholder:text-white/50 focus:border-warning"
                />
              </div>


              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full bg-[#3a1a5c] hover:bg-[#4a2a6c] text-white font-semibold py-6 text-lg rounded-xl gap-2 border border-[#5a2a7c]" 
                size="lg"
                disabled={loading}
              >
                <Save className="w-5 h-5" />
                {loading ? "Saving..." : "Save Review & Earn R2.00"}
                <Coins className="w-5 h-5 text-warning" />
              </Button>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
