import { useAuth } from "@/contexts/AuthContext";
import { useReadingGymSession } from "@/hooks/useReadingGymSession";
import { useLeaderboard } from "@/hooks/useLeaderboard";
import { SessionBanner } from "@/components/reading-gym/SessionBanner";
import { NoActiveSession } from "@/components/reading-gym/NoActiveSession";
import { ReviewForm } from "@/components/reading-gym/ReviewForm";
import { LeaderboardPanel } from "@/components/reading-gym/LeaderboardPanel";
import { MyReviews } from "@/components/reading-gym/MyReviews";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";


export default function ReadingGymPage() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { session, loading: sessionLoading } = useReadingGymSession();
  const { reviews, leaderboard, refresh } = useLeaderboard(session?.id || null);


  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/student-auth", { replace: true });
    }
  }, [authLoading, user, navigate]);


  if (authLoading || sessionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-2xl animate-bounce-soft">🏋️</div>
      </div>
    );
  }


  if (!user) return null;


  return (
    <>
      <SEOHead
        title="Reading Gym | Amabali Champs"
        description="Compete in the Reading Gym! Write book reviews and earn R0.02 per word."
      />
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="flex-1 container max-w-7xl mx-auto px-4 py-6">
          {!session ? (
            <NoActiveSession />
          ) : (
            <div className="space-y-6">
              <SessionBanner
                sessionName={session.session_name}
                endTime={session.end_time}
              />
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                {/* Left panel — form */}
                <div className="lg:col-span-3 space-y-5">
                  <ReviewForm sessionId={session.id} onSubmitted={refresh} />
                  <MyReviews reviews={reviews} userId={user.id} />
                </div>
                {/* Right panel — leaderboard */}
                <div className="lg:col-span-2">
                  <LeaderboardPanel
                    leaderboard={leaderboard}
                    sessionName={session.session_name}
                    currentUserId={user.id}
                  />
                </div>
              </div>
            </div>
          )}
        </main>
        <Footer />
      </div>
    </>
  );
}


import { useParams, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { useLearner } from "@/contexts/LearnerContext";
import { 
  ArrowLeft, 
  BookOpen, 
  Clock, 
  Star,
  ChevronRight,
  Volume2,
  Bookmark,
  Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";


const storiesByLevel: Record<string, Array<{
  id: string;
  title: string;
  author: string;
  wordCount: number;
  readTime: string;
  preview: string;
  category: string;
  completed?: boolean;
}>> = {
  entry: [
    {
      id: "1",
      title: "The Friendly Lion",
      author: "Thandi Mkhize",
      wordCount: 150,
      readTime: "2 min",
      preview: "In the big grasslands of Africa, there lived a lion who loved to make friends...",
      category: "Animals",
    },
    {
      id: "2",
      title: "My First Day at School",
      author: "Sipho Dlamini",
      wordCount: 120,
      readTime: "2 min",
      preview: "Today is a special day! I am going to school for the first time...",
      category: "School Life",
    },
    {
      id: "3",
      title: "The Magic Mielie",
      author: "Nomsa Khumalo",
      wordCount: 180,
      readTime: "3 min",
      preview: "Grandmother planted a mielie seed in the garden. Something magical happened...",
      category: "Fantasy",
    },
    {
      id: "4",
      title: "Rainbow Over the Valley",
      author: "David Mokoena",
      wordCount: 140,
      readTime: "2 min",
      preview: "After the rain stopped, something beautiful appeared in the sky...",
      category: "Nature",
    },
  ],
  intermediate: [
    {
      id: "1",
      title: "The Soccer Championship",
      author: "Bongani Ndlovu",
      wordCount: 450,
      readTime: "5 min",
      preview: "The final match was about to begin. Our team had trained hard for months...",
      category: "Adventure",
    },
    {
      id: "2",
      title: "Mystery of the Missing Homework",
      author: "Lerato Molefe",
      wordCount: 380,
      readTime: "4 min",
      preview: "Everyone in Grade 5 was talking about it. Three students had their homework disappear...",
      category: "Mystery",
    },
    {
      id: "3",
      title: "The Brave Firefighter",
      author: "Mandla Cele",
      wordCount: 420,
      readTime: "5 min",
      preview: "Firefighter Nkosi had been saving people for twenty years. But this fire was different...",
      category: "Real Life",
    },
  ],
  advanced: [
    {
      id: "1",
      title: "The Long Walk to Freedom",
      author: "Adapted from History",
      wordCount: 650,
      readTime: "8 min",
      preview: "In 1962, a man began a journey that would change South Africa forever...",
      category: "History",
    },
    {
      id: "2",
      title: "Climate Warriors",
      author: "Zinhle Nkosi",
      wordCount: 580,
      readTime: "7 min",
      preview: "The young scientists knew they had to act fast. The environment needed heroes...",
      category: "Science",
    },
  ],
};


const levelConfig: Record<string, {
  title: string;
  gradient: string;
  buttonGradient: string;
  glowColor: string;
}> = {
  entry: {
    title: "Entry Level Reader",
    gradient: "bg-card-teal",
    buttonGradient: "bg-gradient-teal",
    glowColor: "shadow-glow-teal",
  },
  intermediate: {
    title: "Intermediate Reader",
    gradient: "bg-card-orange",
    buttonGradient: "bg-gradient-orange",
    glowColor: "shadow-glow-orange",
  },
  advanced: {
    title: "Advanced Reader",
    gradient: "bg-card-purple",
    buttonGradient: "bg-gradient-purple",
    glowColor: "shadow-glow-purple",
  },
};


const ReadingLevelPage = () => {
  const { level } = useParams<{ level: string }>();
  const { learner, updateLearner, addBadge, addPoints } = useLearner();
  const { toast } = useToast();
  const [completedStories, setCompletedStories] = useState<string[]>([]);


  const stories = storiesByLevel[level || "entry"] || [];
  const config = levelConfig[level || "entry"];


  const handleCompleteStory = (storyId: string) => {
    if (!completedStories.includes(storyId)) {
      setCompletedStories([...completedStories, storyId]);
      updateLearner({ storiesRead: learner.storiesRead + 1 });
      addPoints(10);


      if (learner.storiesRead === 0) {
        addBadge("First Story Read");
        toast({
          title: "🎉 Badge Unlocked!",
          description: "You earned the 'First Story Read' badge!",
        });
      }


      toast({
        title: "Story Completed! ✨",
        description: "You earned 10 points!",
      });
    }
  };


  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-slide-up">
          <Link to="/reading">
            <Button variant="ghost" className="gap-2 mb-4 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              Back to Reading Gym
            </Button>
          </Link>
          
          <div className="flex items-center gap-4">
            <div className={cn(
              "w-16 h-16 rounded-2xl flex items-center justify-center",
              config.buttonGradient,
              config.glowColor
            )}>
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                {config.title}
              </h1>
              <p className="text-muted-foreground">
                {stories.length} stories available • Choose one to start reading!
              </p>
            </div>
          </div>
        </div>


        {/* Stories Grid */}
        <div className="space-y-4 mb-8">
          {stories.map((story, index) => {
            const isCompleted = completedStories.includes(story.id);
            
            return (
              <div
                key={story.id}
                className={cn(
                  "bg-card rounded-2xl p-5 border border-border shadow-soft card-hover animate-slide-up",
                  isCompleted && "ring-2 ring-success/50"
                )}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-3 mb-3">
                      <span className={cn(
                        "text-xs px-2 py-1 rounded-full font-medium",
                        config.gradient,
                        "text-foreground"
                      )}>
                        {story.category}
                      </span>
                      {isCompleted && (
                        <span className="flex items-center gap-1 text-xs text-success font-medium">
                          <Check className="w-3 h-3" />
                          Completed
                        </span>
                      )}
                    </div>
                    
                    <h3 className="font-display font-bold text-lg text-foreground mb-1">
                      {story.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      by {story.author}
                    </p>
                    <p className="text-sm text-foreground/80 line-clamp-2">
                      {story.preview}
                    </p>
                    
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {story.readTime}
                      </span>
                      <span>{story.wordCount} words</span>
                    </div>
                  </div>
                  
                  <div className="flex sm:flex-col items-center gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-10 w-10 text-muted-foreground hover:text-foreground"
                    >
                      <Volume2 className="w-5 h-5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-10 w-10 text-muted-foreground hover:text-foreground"
                    >
                      <Bookmark className="w-5 h-5" />
                    </Button>
                    <Button
                      onClick={() => handleCompleteStory(story.id)}
                      className={cn(
                        "gap-2 text-white font-medium",
                        config.buttonGradient,
                        "hover:opacity-90"
                      )}
                      disabled={isCompleted}
                    >
                      {isCompleted ? "Read Again" : "Read Story"}
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>


        {/* Progress */}
        <div className="bg-card rounded-2xl p-6 border border-border shadow-soft animate-slide-up" style={{ animationDelay: "500ms" }}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display font-bold text-foreground">
              Level Progress
            </h3>
            <span className="text-sm text-muted-foreground">
              {completedStories.length} / {stories.length} stories
            </span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div
              className={cn("h-full transition-all duration-500", config.buttonGradient)}
              style={{ width: `${(completedStories.length / stories.length) * 100}%` }}
            />
          </div>
          {completedStories.length === stories.length && (
            <div className="mt-4 flex items-center gap-2 text-success">
              <Star className="w-5 h-5 fill-current" />
              <span className="font-medium">Congratulations! You completed all stories!</span>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};


export default ReadingLevelPage;
