export default ReviewDetailPage;


import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { StarRating } from "@/components/StarRating";
import { SEOHead, generateReviewsListSchema } from "@/components/SEOHead";
import { ReviewStatusBadge } from "@/components/ReviewStatusBadge";
import { VolunteerRatingSlider } from "@/components/VolunteerRatingSlider";
import { ExternalRating } from "@/components/ExternalRating";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { schools } from "@/data/schools";
import { generateReviewPath } from "@/lib/slugify";
import { 
  ArrowLeft, 
  BookOpen, 
  MessageSquare, 
  Edit2, 
  Trash2,
  Building2,
  GraduationCap,
  Calendar,
  User,
  LogIn,
  ExternalLink,
  Percent,
  Send,
  ChevronDown,
  ChevronUp,
  Search
} from "lucide-react";
import { format } from "date-fns";


interface Review {
  id: string;
  review_title: string;
  book_name: string;
  review_content: string;
  star_rating: number;
  school_id: string;
  grade: string;
  student_name: string;
  created_at: string;
  reward_status: "pending" | "rewarded" | "revoked";
  user_id: string;
  avg_external_rating: number | null;
  external_rating_count: number | null;
  language: string | null;
}


interface Feedback {
  id: string;
  review_id: string;
  volunteer_id: string;
  feedback_content: string;
  created_at: string;
  updated_at: string;
  rating: number | null;
  volunteer_name?: string;
  volunteer_company?: string;
  volunteer_job_title?: string;
}


export default function ReviewsFeedPage() {
