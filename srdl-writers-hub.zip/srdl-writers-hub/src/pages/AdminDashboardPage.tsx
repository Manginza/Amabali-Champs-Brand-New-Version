import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Shield, Users, BookOpen, Trash2, Edit, LogOut, ArrowLeft, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { schools } from "@/data/schools";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";


interface Review {
  id: string;
  student_name: string;
  book_name: string;
  review_title: string;
  review_content: string;
  star_rating: number;
  school_id: string;
  grade: string;
  created_at: string;
  user_id: string;
}


interface Profile {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  school_id: string | null;
  grade: string | null;
  company_name: string | null;
  job_title: string | null;
}


interface UserRole {
  user_id: string;
  role: string;
}


const AdminDashboardPage = () => {
  const navigate = useNavigate();
  const { user, role, loading: authLoading, signOut } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  const [editFormData, setEditFormData] = useState({
    review_title: "",
    review_content: "",
  });


  // Redirect if not admin
  useEffect(() => {
    if (!authLoading && (!user || role !== "admin")) {
      navigate("/admin-login");
    }
  }, [user, role, authLoading, navigate]);


  // Fetch reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery({
    queryKey: ["admin-reviews"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("book_reviews")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Review[];
    },
    enabled: role === "admin",
  });


  // Fetch profiles
  const { data: profiles = [], isLoading: profilesLoading } = useQuery({
    queryKey: ["admin-profiles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*");
      if (error) throw error;
      return data as Profile[];
    },
    enabled: role === "admin",
  });


  // Fetch user roles
  const { data: userRoles = [] } = useQuery({
    queryKey: ["admin-user-roles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("*");
      if (error) throw error;
      return data as UserRole[];
    },
    enabled: role === "admin",
  });


  // Delete review mutation
  const deleteReviewMutation = useMutation({
    mutationFn: async (reviewId: string) => {
      const { error } = await supabase.from("book_reviews").delete().eq("id", reviewId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-reviews"] });
      toast({ title: "Review deleted", description: "The review has been removed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete review.", variant: "destructive" });
    },
  });


  // Update review mutation
  const updateReviewMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Review> }) => {
      const { error } = await supabase.from("book_reviews").update(data).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-reviews"] });
      setEditingReview(null);
      toast({ title: "Review updated", description: "The review has been updated." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update review.", variant: "destructive" });
    },
  });


  const getSchoolName = (schoolId: string | null) => {
    if (!schoolId) return "N/A";
    const school = schools.find((s) => s.id === schoolId);
    return school?.name || schoolId;
  };


  const getUserRole = (userId: string) => {
    const userRole = userRoles.find((r) => r.user_id === userId);
    return userRole?.role || "unknown";
  };


  const handleEditClick = (review: Review) => {
    setEditingReview(review);
    setEditFormData({
      review_title: review.review_title,
      review_content: review.review_content,
    });
  };


  const handleEditSave = () => {
    if (editingReview) {
      updateReviewMutation.mutate({
        id: editingReview.id,
        data: editFormData,
      });
    }
  };


  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };


  if (authLoading) {
    return (
      <div className="min-h-screen bg-hero-gradient flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }


  if (role !== "admin") {
    return null;
  }


  return (
    <div className="min-h-screen bg-hero-gradient pb-8">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-purple flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-display font-bold text-xl text-foreground">Admin Dashboard</h1>
              <p className="text-sm text-muted-foreground">Manage reviews and users</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                Home
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2">
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>


      <main className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
              <BookOpen className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reviews.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{profiles.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings Paid</CardTitle>
              <Star className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success">R {reviews.length * 2}.00</div>
            </CardContent>
          </Card>
        </div>


        {/* Tabs */}
        <Tabs defaultValue="reviews" className="space-y-4">
          <TabsList>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
          </TabsList>


          <TabsContent value="reviews">
            <Card>
              <CardHeader>
                <CardTitle>All Book Reviews</CardTitle>
              </CardHeader>
              <CardContent>
                {reviewsLoading ? (
                  <p className="text-muted-foreground">Loading reviews...</p>
                ) : reviews.length === 0 ? (
                  <p className="text-muted-foreground">No reviews yet.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Student</TableHead>
                          <TableHead>Book</TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Rating</TableHead>
                          <TableHead>School</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {reviews.map((review) => (
                          <TableRow key={review.id}>
                            <TableCell className="font-medium">{review.student_name}</TableCell>
                            <TableCell>{review.book_name}</TableCell>
                            <TableCell className="max-w-[200px] truncate">{review.review_title}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 text-warning fill-warning" />
                                {review.star_rating}
                              </div>
                            </TableCell>
                            <TableCell>{getSchoolName(review.school_id)}</TableCell>
                            <TableCell>Grade {review.grade}</TableCell>
                            <TableCell>{new Date(review.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditClick(review)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-destructive hover:text-destructive"
                                  onClick={() => deleteReviewMutation.mutate(review.id)}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>


          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
              </CardHeader>
              <CardContent>
                {profilesLoading ? (
                  <p className="text-muted-foreground">Loading users...</p>
                ) : profiles.length === 0 ? (
                  <p className="text-muted-foreground">No users yet.</p>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Role</TableHead>
                          <TableHead>School</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Company</TableHead>
                          <TableHead>Job Title</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {profiles.map((profile) => (
                          <TableRow key={profile.id}>
                            <TableCell className="font-medium">{profile.full_name}</TableCell>
                            <TableCell>{profile.email}</TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                getUserRole(profile.user_id) === "admin" 
                                  ? "bg-accent/20 text-accent" 
                                  : getUserRole(profile.user_id) === "volunteer"
                                  ? "bg-primary/20 text-primary"
                                  : "bg-muted text-muted-foreground"
                              }`}>
                                {getUserRole(profile.user_id)}
                              </span>
                            </TableCell>
                            <TableCell>{getSchoolName(profile.school_id)}</TableCell>
                            <TableCell>{profile.grade ? `Grade ${profile.grade}` : "N/A"}</TableCell>
                            <TableCell>{profile.company_name || "N/A"}</TableCell>
                            <TableCell>{profile.job_title || "N/A"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>


      {/* Edit Dialog */}
      <Dialog open={!!editingReview} onOpenChange={() => setEditingReview(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Review</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">Review Title</Label>
              <Input
                id="edit-title"
                value={editFormData.review_title}
                onChange={(e) => setEditFormData({ ...editFormData, review_title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-content">Review Content</Label>
              <Textarea
                id="edit-content"
                rows={4}
                value={editFormData.review_content}
                onChange={(e) => setEditFormData({ ...editFormData, review_content: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingReview(null)}>
              Cancel
            </Button>
            <Button onClick={handleEditSave} disabled={updateReviewMutation.isPending}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};


export default AdminDashboardPage;
