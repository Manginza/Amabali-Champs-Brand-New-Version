export default Index;




import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Link } from "react-router-dom";
import { ArrowLeft, Trophy, School, GraduationCap, BookOpen, Medal, Coins, Star, Globe } from "lucide-react";
import { cn } from "@/lib/utils";
import { schools, grades, languages } from "@/data/schools";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";


interface LeaderboardEntry {
  student_name: string;
  school_id: string;
  grade: string;
  language: string;
  review_count: number;
  earnings: number;
  avg_rating: number;
  quality_score: number;
}


const getRankDisplay = (rank: number) => {
  if (rank === 1) return (
    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-500 flex items-center justify-center shadow-lg">
      <Trophy className="w-5 h-5 text-yellow-900" />
    </div>
  );
  if (rank === 2) return (
    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-200 to-gray-400 flex items-center justify-center shadow-lg">
      <Medal className="w-5 h-5 text-gray-700" />
    </div>
  );
  if (rank === 3) return (
    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg">
      <Medal className="w-5 h-5 text-amber-900" />
    </div>
  );
  return (
    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
      <span className="text-lg font-bold text-muted-foreground">{rank}</span>
    </div>
  );
};


const LeaderboardPage = () => {
  const [schoolFilter, setSchoolFilter] = useState<string>("all");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [languageFilter, setLanguageFilter] = useState<string>("all");


  // Fetch leaderboard data from database
  const { data: leaderboardData = [], isLoading } = useQuery({
    queryKey: ["leaderboard"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_student_leaderboard");
      if (error) throw error;
      return (data || []) as LeaderboardEntry[];
    },
  });


  const filteredData = leaderboardData.filter((entry) => {
    if (schoolFilter !== "all" && entry.school_id !== schoolFilter) return false;
    if (gradeFilter !== "all" && entry.grade !== gradeFilter) return false;
    if (languageFilter !== "all" && entry.language !== languageFilter) return false;
    return true;
  });


  const getSchoolName = (schoolId: string) => {
    const school = schools.find((s) => s.id === schoolId);
    return school?.name || schoolId;
  };


  return (
    <div className="min-h-screen bg-hero-gradient pb-24 md:pb-8 md:pt-20">
      <Navbar />


      <main className="container mx-auto px-4 py-8 max-w-5xl">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8 animate-slide-up">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-orange flex items-center justify-center shadow-glow-orange">
              <Trophy className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
                Author Leaderboard
              </h1>
              <p className="text-muted-foreground">Rankings based on weighted quality score</p>
            </div>
          </div>
          
          <Link to="/">
            <Button variant="ghost" className="gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>


        {/* Filters */}
        <div className="grid sm:grid-cols-3 gap-4 mb-6 animate-slide-up" style={{ animationDelay: "100ms" }}>
          <div>
            <label className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
              <School className="w-4 h-4 text-primary" />
              Filter by School
            </label>
            <Select value={schoolFilter} onValueChange={setSchoolFilter}>
              <SelectTrigger className="bg-card border-border">
                <SelectValue placeholder="All Schools" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border z-50">
                <SelectItem value="all">All Schools</SelectItem>
                {schools.map((school) => (
                  <SelectItem key={school.id} value={school.id}>
                    {school.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>


          <div>
            <label className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-secondary" />
              Filter by Grade
            </label>
            <Select value={gradeFilter} onValueChange={setGradeFilter}>
              <SelectTrigger className="bg-card border-border">
                <SelectValue placeholder="All Grades" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border z-50">
                <SelectItem value="all">All Grades</SelectItem>
                {grades.map((grade) => (
                  <SelectItem key={grade.value} value={grade.value}>
                    {grade.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>


          <div>
            <label className="text-sm font-medium text-foreground mb-2 flex items-center gap-2">
              <Globe className="w-4 h-4 text-warning" />
              Filter by Language
            </label>
            <Select value={languageFilter} onValueChange={setLanguageFilter}>
              <SelectTrigger className="bg-card border-border">
                <SelectValue placeholder="All Languages" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border z-50">
                <SelectItem value="all">All Languages</SelectItem>
                {languages.map((lang) => (
                  <SelectItem key={lang.value} value={lang.value}>
                    {lang.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>


        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground">Loading leaderboard...</div>
        ) : leaderboardData.length === 0 ? (
          <div className="bg-card rounded-2xl border border-border p-8 text-center">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="font-display font-bold text-lg text-foreground mb-2">No reviews yet!</h3>
            <p className="text-muted-foreground mb-4">Be the first to write a review and appear on the leaderboard.</p>
            <Link to="/book-review">
              <Button>Write a Review</Button>
            </Link>
          </div>
        ) : (
          <>
            {/* Top 3 Podium */}
            {schoolFilter === "all" && gradeFilter === "all" && languageFilter === "all" && leaderboardData.length >= 3 && (
              <div className="grid grid-cols-3 gap-4 mb-8 animate-slide-up" style={{ animationDelay: "150ms" }}>
                {[1, 0, 2].map((podiumIndex) => {
                  const entry = leaderboardData[podiumIndex];
                  if (!entry) return null;
                  
                  const isFirst = podiumIndex === 0;
                  const rank = podiumIndex === 0 ? 1 : podiumIndex === 1 ? 2 : 3;
                  
                  return (
                    <div
                      key={`podium-${podiumIndex}`}
                      className={cn(
                        "bg-card rounded-2xl p-4 border border-border shadow-soft text-center card-hover",
                        isFirst && "md:-mt-4 ring-2 ring-warning/50"
                      )}
                    >
                      <div className="flex justify-center mb-3">
                        {getRankDisplay(rank)}
                      </div>
                      <h3 className="font-display font-bold text-foreground text-sm md:text-base truncate">
                        {entry.student_name}
                      </h3>
                      <p className="text-xs text-muted-foreground truncate mb-1">
                        Grade {entry.grade} • {entry.language}
                      </p>
                      {entry.avg_rating > 0 && (
                        <div className="flex items-center justify-center gap-1 text-warning text-xs mb-1">
                          <Star className="w-3 h-3 fill-warning" />
                          <span>{entry.avg_rating.toFixed(1)}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-center gap-1 text-success font-bold">
                        <Coins className="w-4 h-4" />
                        <span>R {entry.earnings.toFixed(2)}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}


            {/* Leaderboard List */}
            <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-soft animate-slide-up" style={{ animationDelay: "200ms" }}>
              {/* Table Header */}
              <div className="hidden md:grid grid-cols-12 gap-2 px-4 py-3 bg-muted/50 text-sm font-semibold text-foreground border-b border-border">
                <div className="col-span-1 text-center">Rank</div>
                <div className="col-span-3">Author</div>
                <div className="col-span-2">School & Grade</div>
                <div className="col-span-2 text-center">Reviews</div>
                <div className="col-span-2 text-center">Quality Score</div>
                <div className="col-span-2 text-right">Earnings (ZAR)</div>
              </div>


              {filteredData.length === 0 ? (
                <div className="p-8 text-center text-muted-foreground">
                  No learners found with the selected filters.
                </div>
              ) : (
                filteredData.map((entry, index) => {
                  const rank = index + 1;
                  return (
                    <div
                      key={`${entry.student_name}-${entry.school_id}`}
                      className={cn(
                        "grid grid-cols-12 gap-2 px-4 py-4 items-center transition-colors hover:bg-muted/30",
                        index !== filteredData.length - 1 && "border-b border-border/50"
                      )}
                    >
                      <div className="col-span-2 md:col-span-1 flex justify-center">
                        {getRankDisplay(rank)}
                      </div>
                      
                      <div className="col-span-10 md:col-span-3">
                        <p className="font-semibold text-foreground">{entry.student_name}</p>
                        <p className="text-xs text-muted-foreground md:hidden">
                          {getSchoolName(entry.school_id)} • Grade {entry.grade} • {entry.language}
                        </p>
                      </div>
                      
                      <div className="hidden md:block col-span-2">
                        <div className="flex items-center gap-2 text-sm text-foreground">
                          <School className="w-4 h-4 text-muted-foreground" />
                          <span className="truncate">{getSchoolName(entry.school_id)}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <GraduationCap className="w-4 h-4" />
                          <span>Grade {entry.grade}</span>
                        </div>
                      </div>
                      
                      <div className="hidden md:flex col-span-2 justify-center gap-4">
                        <div className="flex items-center gap-1 text-sm" title="Reviews">
                          <BookOpen className="w-4 h-4 text-primary" />
                          <span className="text-foreground">{entry.review_count}</span>
                        </div>
                      </div>
                      
                      <div className="hidden md:flex col-span-2 justify-center">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 text-warning">
                            <Star className="w-4 h-4 fill-warning" />
                            <span className="text-sm font-bold">{entry.quality_score.toFixed(0)}</span>
                          </div>
                          {entry.avg_rating > 0 && (
                            <span className="text-xs text-muted-foreground">
                              ({entry.avg_rating.toFixed(1)}★)
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="col-span-12 md:col-span-2 flex md:justify-end mt-2 md:mt-0">
                        <div className="flex items-center gap-1 bg-success/10 px-3 py-1 rounded-full">
                          <Coins className="w-4 h-4 text-success" />
                          <span className="font-bold text-success">R {entry.earnings.toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
};


export default LeaderboardPage;
