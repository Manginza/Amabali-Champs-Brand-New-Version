const { learner, updateLearner } = useLearner();


  const selectedSchool = schools.find((s) => s.id === learner.schoolId);


  return (
    <div className={compact ? "flex items-center gap-2" : "flex flex-col sm:flex-row gap-3"}>
      <Select
        value={learner.schoolId || ""}
        onValueChange={(value) => updateLearner({ schoolId: value as SchoolId })}
      >
        <SelectTrigger className={compact ? "w-auto min-w-[180px]" : "w-full sm:w-[260px]"}>
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-primary" />
            <SelectValue placeholder="Select your school" />
          </div>
        </SelectTrigger>
        <SelectContent className="bg-card border-border z-50">
          {schools.map((school) => (
            <SelectItem key={school.id} value={school.id}>
              {school.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>


      {showGrade && (
        <Select
          value={learner.grade || ""}
          onValueChange={(value) => updateLearner({ grade: value as GradeValue })}
        >
          <SelectTrigger className={compact ? "w-auto min-w-[120px]" : "w-full sm:w-[140px]"}>
            <div className="flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-secondary" />
              <SelectValue placeholder="Grade" />
            </div>
          </SelectTrigger>
          <SelectContent className="bg-card border-border z-50">
            {grades.map((grade) => (
              <SelectItem key={grade.value} value={grade.value}>
                {grade.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}


import { useEffect } from "react";


interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  ogImage?: string;
  ogType?: string;
  canonicalUrl?: string;
  structuredData?: object;
  geoRegion?: string;
  geoPlacename?: string;
}


export const SEOHead = ({
