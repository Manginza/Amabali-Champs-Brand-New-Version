return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {quickActions.map((action, index) => (
        <Link
          key={action.path}
          to={action.path}
          className={cn(
            "group relative bg-card rounded-2xl p-5 border border-border transition-all duration-300 card-hover",
            action.shadowGlow
          )}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div
            className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110",
              action.gradient
            )}
          >
            <action.icon className="w-6 h-6 text-white" />
          </div>
          <h3 className="font-display font-bold text-foreground mb-1">
            {action.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {action.description}
          </p>
        </Link>
      ))}
    </div>
  );
}
import { Flame, Trophy, Star } from "lucide-react";
import { useLearner } from "@/contexts/LearnerContext";
import { cn } from "@/lib/utils";


export function ReadingStreakCard() {
