const { learner } = useLearner();
  
  const streakDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const completedDays = Math.min(learner.readingStreak % 7, 7);


  return (
    <div className="bg-card rounded-2xl p-6 shadow-soft border border-border card-hover">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-orange flex items-center justify-center shadow-glow-orange">
            <Flame className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-foreground">
              Reading Streak
            </h3>
            <p className="text-sm text-muted-foreground">
              Keep reading every day!
            </p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-3xl font-display font-bold text-secondary">
            {learner.readingStreak}
          </span>
          <p className="text-xs text-muted-foreground">days</p>
        </div>
      </div>


      <div className="flex items-center justify-between gap-2">
        {streakDays.map((day, index) => (
          <div
            key={day}
            className={cn(
              "flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-all",
              index < completedDays
                ? "bg-gradient-orange text-white"
                : "bg-muted text-muted-foreground"
            )}
          >
            <Star
              className={cn(
                "w-4 h-4",
                index < completedDays ? "fill-current" : ""
              )}
            />
            <span className="text-xs font-medium">{day}</span>
          </div>
        ))}
      </div>


      {learner.readingStreak >= 7 && (
        <div className="mt-4 flex items-center gap-2 text-success">
          <Trophy className="w-5 h-5" />
          <span className="text-sm font-medium">
            Amazing! You completed a full week!
          </span>
        </div>
      )}
    </div>
  );
}
import { CheckCircle2, Lightbulb } from "lucide-react";


const guidelines = [
  { title: "Spelling & Grammar", desc: "Check your spelling, punctuation, and sentence structure before submitting" },
  { title: "Clarity", desc: "Write in a way that others can easily understand your thoughts" },
  { title: "Honesty", desc: "Share your genuine opinions about the book" },
  { title: "Structure", desc: "Include what the book is about, what you liked/disliked, and your overall rating" },
  { title: "Length", desc: "Write a meaningful review (minimum 50-100 words recommended)" },
  { title: "Respect", desc: "Be respectful in your critique of the book" },
];


export const ReviewGuidelines = () => {
