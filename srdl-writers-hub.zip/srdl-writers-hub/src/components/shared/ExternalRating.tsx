const config = badgeConfig[name] || { icon: Star, color: "bg-gradient-teal" };
  const Icon = config.icon;


  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className={cn(
          "rounded-full flex items-center justify-center transition-all duration-300",
          sizeClasses[size],
          unlocked
            ? cn(config.color, "shadow-lg")
            : "bg-muted opacity-50 grayscale"
        )}
      >
        <Icon className={cn(iconSizes[size], "text-white")} />
      </div>
      <span
        className={cn(
          "text-xs font-medium text-center",
          unlocked ? "text-foreground" : "text-muted-foreground"
        )}
      >
        {name}
      </span>
    </div>
  );
}
import { useState } from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getSessionId } from "@/lib/sessionStorage";


interface ExternalRatingProps {
  targetType: "review" | "story";
  targetId: string;
  currentRating: number;
  ratingCount: number;
  onRatingSubmitted?: () => void;
}


export function ExternalRating({
