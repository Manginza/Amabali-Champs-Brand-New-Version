onSubmit,
  disabled = false,
  existingRating,
  existingFeedback = "",
}: VolunteerRatingSliderProps) {
  const [rating, setRating] = useState<number>(existingRating ?? 75);
  const [feedback, setFeedback] = useState(existingFeedback);
  const [submitting, setSubmitting] = useState(false);


  const getRatingColor = (value: number) => {
    if (value < 50) return "text-destructive";
    if (value < 70) return "text-warning";
    return "text-success";
  };


  const getRatingLabel = (value: number) => {
    if (value < 30) return "Needs Improvement";
    if (value < 50) return "Below Average";
    if (value < 70) return "Good";
    if (value < 85) return "Very Good";
    return "Excellent";
  };


  const handleSubmit = async () => {
    if (!feedback.trim()) return;
    setSubmitting(true);
    try {
      await onSubmit(rating, feedback);
      if (!existingRating) {
        setFeedback("");
        setRating(75);
      }
    } finally {
      setSubmitting(false);
    }
  };


  return (
    <div className="space-y-4 p-4 bg-muted/30 rounded-xl border border-border">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-foreground">
            Quality Rating
          </label>
          <div className="flex items-center gap-2">
            <span className={`text-2xl font-bold ${getRatingColor(rating)}`}>
              {rating}%
            </span>
            <Badge
              variant="outline"
              className={`${getRatingColor(rating)} border-current`}
            >
              {getRatingLabel(rating)}
            </Badge>
          </div>
        </div>


        <Slider
          value={[rating]}
          onValueChange={([value]) => setRating(value)}
          min={0}
          max={100}
          step={1}
          disabled={disabled}
          className="w-full"
        />


        <div className="flex justify-between text-xs text-muted-foreground">
          <span>0%</span>
          <span className="text-warning">50% (Reward threshold)</span>
          <span>100%</span>
        </div>


        {rating < 50 && (
          <div className="flex items-start gap-2 p-3 bg-destructive/10 rounded-lg border border-destructive/20">
            <AlertTriangle className="w-4 h-4 text-destructive mt-0.5" />
            <p className="text-xs text-destructive">
              Ratings below 50% will revoke the learner's R2 reward for this review.
            </p>
          </div>
        )}
      </div>


      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">
          Feedback Comment
        </label>
        <Textarea
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          placeholder="Provide constructive feedback for the learner..."
          rows={3}
          disabled={disabled}
        />
      </div>


      <Button
        onClick={handleSubmit}
        disabled={disabled || submitting || !feedback.trim()}
        className="w-full"
      >
        <Send className="w-4 h-4 mr-2" />
        {existingRating !== undefined ? "Update Feedback" : "Submit Feedback & Rating"}
      </Button>
    </div>
  );
}


import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { User, Session } from "@supabase/supabase-js";
