return (
    <div className="bg-card rounded-2xl p-6 border border-border shadow-soft">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg">
          <Trophy className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="font-display font-bold text-xl text-foreground">
            Story Leaderboard
          </h2>
          <p className="text-sm text-muted-foreground">
            Top stories ranked by volunteer reviews
          </p>
        </div>
      </div>


      <div className="space-y-3">
        {topStories.map((story, index) => {
          const rank = index + 1;
          const freshnessScore = getFreshnessScore(story.avgRating, story.reviewCount);
          const freshness = getFreshnessLabel(freshnessScore);


          return (
            <div
              key={story.id}
              className={cn(
                "flex items-center gap-4 p-4 rounded-xl border transition-all hover:shadow-md",
                rank === 1 ? "bg-gradient-to-r from-amber-500/10 to-transparent border-amber-500/30" :
                rank === 2 ? "bg-gradient-to-r from-slate-400/10 to-transparent border-slate-400/30" :
                rank === 3 ? "bg-gradient-to-r from-orange-700/10 to-transparent border-orange-700/30" :
                "bg-muted/30 border-border"
              )}
            >
              {getRankIcon(rank)}


              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-display font-bold text-foreground truncate">
                    {story.title}
                  </h3>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-accent/20 text-accent-foreground">
                    {story.category}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <BookOpen className="w-3 h-3" />
                  <span className="truncate">by {story.author} • {story.school}</span>
                </div>
              </div>


              <div className="text-right flex-shrink-0">
                <div className={cn("text-2xl font-bold", freshness.color)}>
                  {freshnessScore}%
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <ThumbsUp className="w-3 h-3" />
                    {story.reviewCount}
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 fill-warning text-warning" />
                    {story.avgRating.toFixed(1)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>


      <div className="mt-6 pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground text-center">
          🍅 Scores based on volunteer reviews — like Rotten Tomatoes for student stories!
        </p>
      </div>
    </div>
  );
};


import { useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, AlertTriangle } from "lucide-react";


interface VolunteerRatingSliderProps {
  onSubmit: (rating: number, feedback: string) => Promise<void>;
  disabled?: boolean;
  existingRating?: number;
  existingFeedback?: string;
}


export function VolunteerRatingSlider({
