return (
    <div
      className={cn(
        "p-6 rounded-2xl border backdrop-blur-sm animate-slide-up card-hover text-center",
        variantStyles[variant]
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      <Icon className={cn("w-8 h-8 mx-auto mb-3", iconStyles[variant])} />
      <p className="text-3xl md:text-4xl font-display font-bold text-foreground mb-1">
        {value}
      </p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}


import { Trophy, Star, ThumbsUp, BookOpen } from "lucide-react";
import { cn } from "@/lib/utils";


interface Story {
  id: string;
  title: string;
  author: string;
  school: string;
  reviewCount: number;
  avgRating: number;
  category: string;
}


// Mock data - in production, this would come from Supabase
const topStories: Story[] = [
  {
    id: "1",
    title: "The Magic Paintbrush",
    author: "Amahle Nkosi",
    school: "Sikelela Primary",
    reviewCount: 45,
    avgRating: 4.8,
    category: "Fantasy",
  },
  {
    id: "2",
    title: "My Hero Grandmother",
    author: "Siya Radebe",
    school: "Entshona Primary",
    reviewCount: 38,
    avgRating: 4.6,
    category: "Real Life",
  },
  {
    id: "3",
    title: "The Soccer Match Mystery",
    author: "Thabo Moloi",
    school: "Mzamomhle Primary",
    reviewCount: 32,
    avgRating: 4.5,
    category: "Mystery",
  },
  {
    id: "4",
    title: "Journey to the Stars",
    author: "Lindiwe Khumalo",
    school: "Bhongolethu Primary",
    reviewCount: 28,
    avgRating: 4.3,
    category: "Science Fiction",
  },
  {
    id: "5",
    title: "The Friendly Lion",
    author: "Zinhle Dlamini",
    school: "Sikelela Primary",
    reviewCount: 25,
    avgRating: 4.2,
    category: "Animals",
  },
];


const getRankColor = (rank: number) => {
  switch (rank) {
    case 1: return "from-[#FFD700] to-[#FFA500]";
    case 2: return "from-[#C0C0C0] to-[#A0A0A0]";
    case 3: return "from-[#CD7F32] to-[#8B4513]";
    default: return "from-muted to-muted";
  }
};


const getRankIcon = (rank: number) => {
  if (rank <= 3) {
    return (
      <div className={cn(
        "w-8 h-8 rounded-full flex items-center justify-center bg-gradient-to-br shadow-md",
        getRankColor(rank)
      )}>
        <Trophy className="w-4 h-4 text-white" />
      </div>
    );
  }
  return (
    <div className="w-8 h-8 rounded-full flex items-center justify-center bg-muted text-muted-foreground font-bold">
      {rank}
    </div>
  );
};


// Calculate freshness score (like Rotten Tomatoes)
const getFreshnessScore = (avgRating: number, reviewCount: number) => {
  const normalizedRating = (avgRating / 5) * 100;
  const reviewBonus = Math.min(reviewCount / 50, 1) * 10;
  return Math.round(normalizedRating + reviewBonus);
};


const getFreshnessLabel = (score: number) => {
  if (score >= 90) return { label: "Certified Fresh 🍅", color: "text-success" };
  if (score >= 75) return { label: "Fresh 🍅", color: "text-success" };
  if (score >= 60) return { label: "Mixed 🍿", color: "text-warning" };
  return { label: "Needs Work 📚", color: "text-muted-foreground" };
};


export const StoryLeaderboard = () => {
