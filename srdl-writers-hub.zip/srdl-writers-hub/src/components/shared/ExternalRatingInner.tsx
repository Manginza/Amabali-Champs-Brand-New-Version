targetType,
  targetId,
  currentRating,
  ratingCount,
  onRatingSubmitted,
}: ExternalRatingProps) {
  const { toast } = useToast();
  const [hoveredRating, setHoveredRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [hasRated, setHasRated] = useState(false);


  const handleRate = async (rating: number) => {
    if (hasRated || submitting) return;


    setSubmitting(true);
    try {
      const sessionId = getSessionId();
      
      const { error } = await supabase.from("external_ratings").insert({
        target_type: targetType,
        target_id: targetId,
        rating,
        session_id: sessionId,
      });


      if (error) throw error;


      setHasRated(true);
      toast({
        title: "Rating Submitted!",
        description: `You rated this ${targetType} ${rating} star${rating > 1 ? "s" : ""}.`,
      });
      
      onRatingSubmitted?.();
    } catch (error: any) {
      // Check if it's a duplicate rating error (unique constraint violation)
      const isDuplicate = error?.code === "23505" || 
        error?.message?.includes("unique constraint") ||
        error?.message?.includes("duplicate");
      
      if (isDuplicate) {
        setHasRated(true);
        toast({
          title: "Already Rated",
          description: `You've already rated this ${targetType}. Thank you!`,
        });
      } else {
        // Sanitize error message - don't expose database details
        toast({
          title: "Rating Failed",
          description: "Something went wrong. Please try again later.",
          variant: "destructive",
        });
      }
    }
    setSubmitting(false);
  };


  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            disabled={hasRated || submitting}
            onClick={() => handleRate(star)}
            onMouseEnter={() => setHoveredRating(star)}
            onMouseLeave={() => setHoveredRating(0)}
            className={cn(
              "transition-all duration-150",
              hasRated ? "cursor-default" : "cursor-pointer hover:scale-110",
              submitting && "opacity-50"
            )}
          >
            <Star
              className={cn(
                "w-5 h-5 transition-colors",
                (hoveredRating >= star || (hasRated && currentRating >= star))
                  ? "fill-warning text-warning"
                  : "text-muted-foreground"
              )}
            />
          </button>
        ))}
      </div>
      <div className="text-sm text-muted-foreground">
        {ratingCount > 0 ? (
          <span>
            {currentRating.toFixed(1)} ({ratingCount} rating{ratingCount !== 1 ? "s" : ""})
          </span>
        ) : (
          <span>No ratings yet</span>
        )}
      </div>
      {hasRated && (
        <span className="text-xs text-success font-medium">✓ Rated</span>
      )}
    </div>
  );
}
import { Link } from "react-router-dom";
import { Shield } from "lucide-react";


export function Footer() {
