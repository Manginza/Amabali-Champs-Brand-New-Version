return (
    <div className="bg-card rounded-2xl p-6 border border-border shadow-soft mb-6">
      <div className="flex items-center gap-2 mb-4">
        <Lightbulb className="w-5 h-5 text-warning" />
        <h3 className="font-display font-bold text-foreground">
          What Makes a Good Book Review?
        </h3>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        {guidelines.map((item, index) => (
          <div key={index} className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-success mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-medium text-foreground text-sm">{item.title}:</span>
              <span className="text-muted-foreground text-sm ml-1">{item.desc}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, XCircle } from "lucide-react";


interface ReviewStatusBadgeProps {
  status: "pending" | "rewarded" | "revoked";
  showLabel?: boolean;
}


export function ReviewStatusBadge({ status, showLabel = true }: ReviewStatusBadgeProps) {
