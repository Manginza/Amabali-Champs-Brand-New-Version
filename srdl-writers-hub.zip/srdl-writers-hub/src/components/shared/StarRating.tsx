rating,
  maxRating = 5,
  onRate,
  size = "md",
  interactive = false,
}: StarRatingProps) {
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: maxRating }).map((_, index) => {
        const isFilled = index < rating;
        return (
          <button
            key={index}
            type="button"
            disabled={!interactive}
            onClick={() => onRate?.(index + 1)}
            className={cn(
              "transition-all duration-200",
              interactive && "cursor-pointer hover:scale-110",
              !interactive && "cursor-default"
            )}
          >
            <Star
              className={cn(
                sizeClasses[size],
                isFilled
                  ? "fill-warning text-warning"
                  : "text-muted-foreground/30"
              )}
            />
          </button>
        );
      })}
    </div>
  );
}


import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";


interface StatCardProps {
  icon: LucideIcon;
  value: string;
  label: string;
  variant?: "default" | "orange" | "teal" | "purple";
  delay?: number;
}


const variantStyles = {
  default: "bg-card border-border/50",
  orange: "bg-primary/10 border-primary/30",
  teal: "bg-secondary/10 border-secondary/30",
  purple: "bg-accent/10 border-accent/30",
};


const iconStyles = {
  default: "text-muted-foreground",
  orange: "text-primary",
  teal: "text-secondary",
  purple: "text-accent",
};


export function StatCard({ icon: Icon, value, label, variant = "default", delay = 0 }: StatCardProps) {
