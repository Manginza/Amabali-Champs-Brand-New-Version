const config = {
    pending: {
      icon: Clock,
      label: "Pending Feedback",
      className: "bg-warning/20 text-warning border-warning/30",
    },
    rewarded: {
      icon: CheckCircle,
      label: "Reward Confirmed",
      className: "bg-success/20 text-success border-success/30",
    },
    revoked: {
      icon: XCircle,
      label: "Reward Revoked",
      className: "bg-destructive/20 text-destructive border-destructive/30",
    },
  };


  const { icon: Icon, label, className } = config[status] || config.pending;


  return (
    <Badge variant="outline" className={`gap-1 ${className}`}>
      <Icon className="w-3 h-3" />
      {showLabel && <span>{label}</span>}
    </Badge>
  );
}
import { useLearner } from "@/contexts/LearnerContext";
import { schools, grades, SchoolId, GradeValue } from "@/data/schools";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GraduationCap, School } from "lucide-react";


interface SchoolSelectorProps {
  showGrade?: boolean;
  compact?: boolean;
}


export function SchoolSelector({ showGrade = true, compact = false }: SchoolSelectorProps) {
