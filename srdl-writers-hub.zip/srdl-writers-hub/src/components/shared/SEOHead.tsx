title,
  description,
  keywords,
  ogImage = "https://lovable.dev/opengraph-image-p98pqg.png",
  ogType = "website",
  canonicalUrl,
  structuredData,
  geoRegion = "ZA",
  geoPlacename = "South Africa",
}: SEOHeadProps) => {
  useEffect(() => {
    // Update document title
    document.title = title;


    // Helper to create or update meta tags
    const setMetaTag = (selector: string, attr: string, value: string) => {
      let meta = document.querySelector(selector);
      if (meta) {
        meta.setAttribute(attr, value);
      } else {
        meta = document.createElement("meta");
        const [type, name] = selector.replace(/[\[\]'"]/g, '').split('=');
        if (type.includes('property')) {
          meta.setAttribute('property', name);
        } else if (type.includes('name')) {
          meta.setAttribute('name', name);
        }
        meta.setAttribute(attr, value);
        document.head.appendChild(meta);
      }
    };


    // Update meta description
    setMetaTag('meta[name="description"]', "content", description);


    // Update keywords
    if (keywords) {
      setMetaTag('meta[name="keywords"]', "content", keywords);
    }


    // Update OG tags
    setMetaTag('meta[property="og:title"]', "content", title);
    setMetaTag('meta[property="og:description"]', "content", description);
    setMetaTag('meta[property="og:image"]', "content", ogImage);
    setMetaTag('meta[property="og:type"]', "content", ogType);


    // Add geo targeting meta tags
    let geoRegionMeta = document.querySelector('meta[name="geo.region"]');
    if (!geoRegionMeta) {
      geoRegionMeta = document.createElement("meta");
      geoRegionMeta.setAttribute("name", "geo.region");
      document.head.appendChild(geoRegionMeta);
    }
    geoRegionMeta.setAttribute("content", geoRegion);


    let geoPlacenameMeta = document.querySelector('meta[name="geo.placename"]');
    if (!geoPlacenameMeta) {
      geoPlacenameMeta = document.createElement("meta");
      geoPlacenameMeta.setAttribute("name", "geo.placename");
      document.head.appendChild(geoPlacenameMeta);
    }
    geoPlacenameMeta.setAttribute("content", geoPlacename);


    // Add content language meta
    let contentLanguage = document.querySelector('meta[http-equiv="content-language"]');
    if (!contentLanguage) {
      contentLanguage = document.createElement("meta");
      contentLanguage.setAttribute("http-equiv", "content-language");
      document.head.appendChild(contentLanguage);
    }
    contentLanguage.setAttribute("content", "en-ZA");


    // Update canonical URL
    if (canonicalUrl) {
      let canonical = document.querySelector('link[rel="canonical"]');
      if (canonical) {
        canonical.setAttribute("href", canonicalUrl);
      }
    }


    // Add structured data
    if (structuredData) {
      // Remove any existing structured data with same type
      const existingScripts = document.querySelectorAll('script[type="application/ld+json"]');
      existingScripts.forEach(script => script.remove());


      // Add new structured data
      const script = document.createElement("script");
      script.type = "application/ld+json";
      script.text = JSON.stringify(structuredData);
      document.head.appendChild(script);


      return () => {
        script.remove();
      };
    }
  }, [title, description, keywords, ogImage, ogType, canonicalUrl, structuredData, geoRegion, geoPlacename]);


  return null;
};


// Helper to generate review schema with enhanced SEO
export const generateReviewSchema = (review: {
