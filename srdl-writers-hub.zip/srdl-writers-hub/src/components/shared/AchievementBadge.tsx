import { cn } from "@/lib/utils";
import { 
  BookOpen, 
  Star, 
  Flame, 
  Trophy, 
  PenTool, 
  Sparkles,
  Award,
  Zap,
  Target,
  Heart
} from "lucide-react";


interface AchievementBadgeProps {
  name: string;
  unlocked?: boolean;
  size?: "sm" | "md" | "lg";
}


const badgeConfig: Record<string, { icon: React.ElementType; color: string }> = {
  "First Login": { icon: Star, color: "bg-gradient-teal" },
  "First Story Read": { icon: BookOpen, color: "bg-gradient-teal" },
  "7-Day Streak": { icon: Flame, color: "bg-gradient-orange" },
  "First Story Written": { icon: PenTool, color: "bg-gradient-purple" },
  "100 Words Written": { icon: Award, color: "bg-gradient-orange" },
  "Reading Champion": { icon: Trophy, color: "bg-gradient-teal" },
  "Super Writer": { icon: Sparkles, color: "bg-gradient-purple" },
  "Speed Reader": { icon: Zap, color: "bg-gradient-orange" },
  "Goal Crusher": { icon: Target, color: "bg-gradient-teal" },
  "Helpful Friend": { icon: Heart, color: "bg-gradient-purple" },
};


const sizeClasses = {
  sm: "w-10 h-10",
  md: "w-14 h-14",
  lg: "w-20 h-20",
};


const iconSizes = {
  sm: "w-5 h-5",
  md: "w-7 h-7",
  lg: "w-10 h-10",
};


export function AchievementBadge({ name, unlocked = true, size = "md" }: AchievementBadgeProps) {
