export function Footer() {
  return (
    <footer className="bg-card/80 backdrop-blur-sm border-t border-border py-4 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} ReadingQuest. Empowering young readers.</p>
          <Link
            to="/admin-login"
            className="flex items-center gap-1 hover:text-foreground transition-colors opacity-40 hover:opacity-70"
          >
            <Shield className="w-3 h-3" />
            <span className="text-xs">Admin</span>
          </Link>
        </div>
      </div>
    </footer>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wallet, TrendingUp, TrendingDown, Clock, CheckCircle, XCircle } from "lucide-react";


interface WalletProps {
  balance: number;
  rewardHistory: {
    id: string;
    type: "reward" | "penalty";
    amount: number;
    reason: string;
    date: string;
    status: "pending" | "rewarded" | "revoked";
  }[];
}


export function LearnerWallet({ balance, rewardHistory }: WalletProps) {
