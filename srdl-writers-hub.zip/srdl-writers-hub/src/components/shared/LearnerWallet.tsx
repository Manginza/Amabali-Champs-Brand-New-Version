return (
    <Card className="border-border shadow-soft">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="w-10 h-10 rounded-xl bg-gradient-success flex items-center justify-center">
            <Wallet className="w-5 h-5 text-white" />
          </div>
          My Earnings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center py-4 mb-4 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl">
          <p className="text-sm text-muted-foreground mb-1">Current Balance</p>
          <p className="text-4xl font-display font-bold text-primary">R{balance.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground mt-2">
            Minimum R50 required for withdrawal
          </p>
        </div>


        <div className="space-y-3">
          <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
            Recent Activity
          </h4>
          {rewardHistory.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              No earnings yet. Submit a review to earn R2!
            </p>
          ) : (
            rewardHistory.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 rounded-lg bg-muted/50"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      item.status === "revoked"
                        ? "bg-destructive/10"
                        : item.status === "rewarded"
                        ? "bg-success/10"
                        : "bg-warning/10"
                    }`}
                  >
                    {item.status === "revoked" ? (
                      <XCircle className="w-4 h-4 text-destructive" />
                    ) : item.status === "rewarded" ? (
                      <CheckCircle className="w-4 h-4 text-success" />
                    ) : (
                      <Clock className="w-4 h-4 text-warning" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {item.reason}
                    </p>
                    <p className="text-xs text-muted-foreground">{item.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={item.status === "revoked" ? "destructive" : "default"}
                    className={
                      item.status === "rewarded"
                        ? "bg-success/20 text-success hover:bg-success/30"
                        : item.status === "pending"
                        ? "bg-warning/20 text-warning hover:bg-warning/30"
                        : ""
                    }
                  >
                    {item.status === "revoked" ? (
                      <>
                        <TrendingDown className="w-3 h-3 mr-1" />
                        -R{item.amount}
                      </>
                    ) : (
                      <>
                        <TrendingUp className="w-3 h-3 mr-1" />
                        +R{item.amount}
                      </>
                    )}
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}


import { Link, useLocation } from "react-router-dom";
import { Home, PenTool, Star, User, GraduationCap, FileEdit, BookText, Users, Dumbbell } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";


const navItems = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/stories", icon: BookText, label: "Stories" },
  { path: "/reviews-feed", icon: Star, label: "Reviews" },
  { path: "/create", icon: PenTool, label: "Create Story" },
  { path: "/book-review", icon: FileEdit, label: "Write Review" },
  { path: "https://reading-gym-champs.lovable.app/reading-gym", icon: Dumbbell, label: "Reading Gym", external: true },
  { path: "/volunteer-auth", icon: Users, label: "Volunteer" },
];


export function Navbar() {
