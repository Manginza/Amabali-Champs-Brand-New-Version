const location = useLocation();
  const currentPath = location.pathname;
  const { user, role } = useAuth();


  const isActive = (path: string) => {
    if (path === "/") return currentPath === "/";
    return currentPath.startsWith(path);
  };


  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-lg border-t border-border shadow-lg md:top-0 md:bottom-auto md:border-t-0 md:border-b">
      <div className="container mx-auto px-4">
        {/* Desktop Logo */}
        <div className="hidden md:flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-teal flex items-center justify-center">
              <BookText className="w-6 h-6 text-white" />
            </div>
            <span className="font-display font-bold text-xl text-foreground">
              Reading<span className="text-primary">Quest</span>
            </span>
          </Link>


          <div className="flex items-center gap-1">
            {navItems.map((item) =>
              item.external ? (
                <a
                  key={item.path}
                  href={item.path}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200",
                    "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </a>
              ) : (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200",
                    isActive(item.path)
                      ? "bg-primary text-primary-foreground shadow-glow-teal"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              )
            )}
            
            {/* Student Registration Link */}
            {!user && (
              <Link
                to="/student-auth"
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-xl transition-all duration-200",
                  currentPath === "/student-auth"
                    ? "bg-primary text-primary-foreground shadow-glow-teal"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <GraduationCap className="w-5 h-5" />
                <span className="font-medium">Student Login</span>
              </Link>
            )}
          </div>
        </div>


        {/* Mobile Navigation */}
        <div className="flex md:hidden items-center justify-around h-16 pb-safe">
          {navItems.map((item) =>
            item.external ? (
              <a
                key={item.path}
                href={item.path}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center gap-1 px-2 py-2 rounded-xl transition-all duration-200 min-w-[56px] text-muted-foreground"
              >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 hover:bg-muted">
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-medium">{item.label}</span>
              </a>
            ) : (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex flex-col items-center gap-1 px-2 py-2 rounded-xl transition-all duration-200 min-w-[56px]",
                  isActive(item.path)
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                <div
                  className={cn(
                    "w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200",
                    isActive(item.path)
                      ? "bg-primary text-primary-foreground shadow-glow-teal"
                      : "hover:bg-muted"
                  )}
                >
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-medium">{item.label}</span>
              </Link>
            )
          )}
          
          {/* Mobile Student Login Link */}
          {!user && (
            <Link
              to="/student-auth"
              className={cn(
                "flex flex-col items-center gap-1 px-2 py-2 rounded-xl transition-all duration-200 min-w-[56px]",
                currentPath === "/student-auth"
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              <div
                className={cn(
                  "w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200",
                  currentPath === "/student-auth"
                    ? "bg-primary text-primary-foreground shadow-glow-teal"
                    : "hover:bg-muted"
                )}
              >
                <GraduationCap className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-medium">Student</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
import { NavLink as RouterNavLink, NavLinkProps } from "react-router-dom";
import { forwardRef } from "react";
import { cn } from "@/lib/utils";


interface NavLinkCompatProps extends Omit<NavLinkProps, "className"> {
  className?: string;
  activeClassName?: string;
  pendingClassName?: string;
}


const NavLink = forwardRef<HTMLAnchorElement, NavLinkCompatProps>(
  ({ className, activeClassName, pendingClassName, to, ...props }, ref) => {
    return (
      <RouterNavLink
        ref={ref}
        to={to}
        className={({ isActive, isPending }) =>
          cn(className, isActive && activeClassName, isPending && pendingClassName)
        }
        {...props}
      />
    );
  },
);


NavLink.displayName = "NavLink";


export { NavLink };
