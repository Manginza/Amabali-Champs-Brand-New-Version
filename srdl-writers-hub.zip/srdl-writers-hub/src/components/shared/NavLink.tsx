import { Link } from "react-router-dom";
import { BookOpen, PenTool, Star, Trophy, Sparkles, Target } from "lucide-react";
import { cn } from "@/lib/utils";


const quickActions = [
  {
    title: "Start Reading",
    description: "Choose a story and begin your adventure",
    icon: BookOpen,
    path: "/reading",
    gradient: "bg-gradient-teal",
    shadowGlow: "hover:shadow-glow-teal",
  },
  {
    title: "Write a Story",
    description: "Let your imagination run wild",
    icon: PenTool,
    path: "/create",
    gradient: "bg-gradient-orange",
    shadowGlow: "hover:shadow-glow-orange",
  },
  {
    title: "Share Feedback",
    description: "Tell us about your learning journey",
    icon: Star,
    path: "/reviews",
    gradient: "bg-gradient-purple",
    shadowGlow: "hover:shadow-glow-purple",
  },
  {
    title: "View Leaderboard",
    description: "See the top readers in your school",
    icon: Trophy,
    path: "/leaderboard",
    gradient: "bg-gradient-teal",
    shadowGlow: "hover:shadow-glow-teal",
  },
];


export function QuickActionsGrid() {
