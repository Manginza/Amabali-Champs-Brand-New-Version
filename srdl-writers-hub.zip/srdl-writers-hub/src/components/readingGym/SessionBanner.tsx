import { useState, useEffect } from "react";
import { Timer } from "lucide-react";


interface SessionBannerProps {
  sessionName: string;
  endTime?: string | null;
}


export function SessionBanner({ sessionName, endTime }: SessionBannerProps) {
  const [timeLeft, setTimeLeft] = useState("");


  useEffect(() => {
    if (!endTime) {
      setTimeLeft("");
      return;
    }


    const tick = () => {
      const diff = new Date(endTime).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft("00:00:00");
        return;
      }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(
        `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
      );
    };


    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [endTime]);


  return (
    <div className="bg-gradient-teal text-primary-foreground rounded-2xl p-4 md:p-6 flex flex-col md:flex-row items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🏋️</span>
        <div>
          <h1 className="font-display text-xl md:text-2xl font-bold">Reading Gym</h1>
          <p className="text-primary-foreground/80 text-sm">{sessionName}</p>
        </div>
      </div>
      {endTime && timeLeft && (
        <div className="flex items-center gap-2 bg-background/20 rounded-xl px-4 py-2">
          <Timer className="w-5 h-5" />
          <span className="font-mono text-xl md:text-2xl font-bold tracking-wider">
            {timeLeft}
          </span>
        </div>
      )}
    </div>
  );
}
