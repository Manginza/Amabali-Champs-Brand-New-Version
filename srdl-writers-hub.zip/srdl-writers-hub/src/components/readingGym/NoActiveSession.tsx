import { BookOpen } from "lucide-react";


export function NoActiveSession() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
      <div className="text-6xl mb-6 animate-bounce-soft">🏋️</div>
      <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-3">
        The Reading Gym is getting ready!
      </h1>
      <p className="text-muted-foreground text-lg max-w-md">
        Come back soon — our next session will be starting shortly. Get your books ready! 📚
      </p>
      <div className="mt-8 flex items-center gap-2 text-muted-foreground">
        <BookOpen className="w-5 h-5" />
        <span className="text-sm">Waiting for session to begin…</span>
      </div>
    </div>
  );
}
