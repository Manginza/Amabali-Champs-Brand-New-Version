import { useEffect } from "react";
import confetti from "canvas-confetti";


interface ConfettiCelebrationProps {
  trigger: boolean;
}


export function ConfettiCelebration({ trigger }: ConfettiCelebrationProps) {
  useEffect(() => {
    if (!trigger) return;
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 },
      colors: ["#00BFA5", "#FF8A50", "#7C3AED", "#FBBF24", "#10B981"],
    });
  }, [trigger]);


  return null;
}
