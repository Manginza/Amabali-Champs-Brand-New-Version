import { motion } from "framer-motion";
import { formatRands, LeaderboardEntry } from "@/lib/readingGym";
import { cn } from "@/lib/utils";


interface LeaderboardRowProps {
  entry: LeaderboardEntry;
  rank: number;
  maxWords: number;
  isCurrentUser: boolean;
}


const rankBadges: Record<number, string> = { 1: "🥇", 2: "🥈", 3: "🥉" };
const rankBg: Record<number, string> = {
  1: "bg-warning/15",
  2: "bg-muted/60",
  3: "bg-orange/10",
};


export function LeaderboardRow({ entry, rank, maxWords, isCurrentUser }: LeaderboardRowProps) {
  const progress = maxWords > 0 ? (entry.total_words / maxWords) * 100 : 0;


  return (
    <motion.div
      layout
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className={cn(
        "flex items-center gap-3 rounded-xl px-3 py-3 transition-colors",
        rankBg[rank] || "bg-card",
        isCurrentUser && "ring-2 ring-success"
      )}
    >
      <div className="w-8 text-center font-display font-bold text-lg shrink-0">
        {rankBadges[rank] || `#${rank}`}
      </div>
      <span className="text-2xl shrink-0">{entry.avatar_emoji}</span>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm truncate text-foreground">{entry.learner_name}</p>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>{entry.review_count} review{entry.review_count !== 1 ? "s" : ""}</span>
          <span>·</span>
          <span>{entry.total_words} words</span>
        </div>
        <div className="mt-1 h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      <div className="text-right shrink-0">
        <span className="font-display font-bold text-success text-sm">
          {formatRands(entry.total_earnings)}
        </span>
      </div>
    </motion.div>
  );
}
