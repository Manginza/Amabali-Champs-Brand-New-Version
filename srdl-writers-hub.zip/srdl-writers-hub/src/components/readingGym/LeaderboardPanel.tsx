import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LeaderboardRow } from "./LeaderboardRow";
import { LeaderboardEntry } from "@/lib/readingGym";
import { AnimatePresence } from "framer-motion";


interface LeaderboardPanelProps {
  leaderboard: LeaderboardEntry[];
  sessionName: string;
  currentUserId: string | null;
}


export function LeaderboardPanel({ leaderboard, sessionName, currentUserId }: LeaderboardPanelProps) {
  const maxWords = leaderboard.length > 0 ? leaderboard[0].total_words : 0;


  return (
    <Card className="h-fit sticky top-4">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-display">Live Leaderboard</CardTitle>
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse-soft" />
            Live
          </span>
        </div>
        <p className="text-xs text-muted-foreground">{sessionName}</p>
      </CardHeader>
      <CardContent className="space-y-2">
        {leaderboard.length === 0 ? (
          <p className="text-center text-muted-foreground py-8 text-sm">
            No reviews yet — be the first! 🚀
          </p>
        ) : (
          <AnimatePresence>
            {leaderboard.map((entry, i) => (
              <LeaderboardRow
                key={entry.learner_id}
                entry={entry}
                rank={i + 1}
                maxWords={maxWords}
                isCurrentUser={entry.learner_id === currentUserId}
              />
            ))}
          </AnimatePresence>
        )}
      </CardContent>
    </Card>
  );
}
