import { formatRands, calcEarnings, MIN_WORDS } from "@/lib/readingGym";


interface WordCounterProps {
  wordCount: number;
}


export function WordCounter({ wordCount }: WordCounterProps) {
  const earnings = calcEarnings(wordCount);
  const remaining = Math.max(0, MIN_WORDS - wordCount);


  return (
    <div className="bg-emerald/10 border border-emerald/30 rounded-xl p-4 space-y-1">
      <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm font-medium">
        <span className="text-foreground">
          ✍️ <strong>{wordCount}</strong> words written
        </span>
        <span className="text-emerald">
          💰 <strong>{formatRands(earnings)}</strong> earned so far
        </span>
        {remaining > 0 && (
          <span className="text-muted-foreground">
            📝 {remaining} more words to submit
          </span>
        )}
      </div>
    </div>
  );
}
