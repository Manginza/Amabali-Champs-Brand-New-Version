import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatRands } from "@/lib/readingGym";
import { format } from "date-fns";


interface MyReviewsProps {
  reviews: any[];
  userId: string;
}


export function MyReviews({ reviews, userId }: MyReviewsProps) {
  const myReviews = reviews.filter((r: any) => r.learner_id === userId);
  if (myReviews.length === 0) return null;


  const totalEarnings = myReviews.reduce((sum: number, r: any) => sum + r.earnings_cents, 0);


  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-display">My Reviews This Session</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {myReviews.map((r: any) => (
            <div
              key={r.id}
              className="flex items-center justify-between text-sm bg-muted/50 rounded-lg px-3 py-2"
            >
              <span className="font-medium truncate flex-1 text-foreground">{r.book_title}</span>
              <span className="text-muted-foreground mx-2">{r.word_count} words</span>
              <span className="text-success font-semibold">{formatRands(r.earnings_cents)}</span>
              <span className="text-muted-foreground text-xs ml-2 hidden sm:inline">
                {format(new Date(r.submitted_at), "HH:mm")}
              </span>
            </div>
          ))}
        </div>
        <div className="mt-3 pt-3 border-t border-border flex justify-between text-sm font-semibold">
          <span className="text-foreground">Total earned this session:</span>
          <span className="text-success">{formatRands(totalEarnings)}</span>
        </div>
      </CardContent>
    </Card>
  );
}
