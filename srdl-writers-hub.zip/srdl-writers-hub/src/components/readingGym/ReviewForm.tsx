import { useState, useMemo } from "react";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { WordCounter } from "./WordCounter";
import { EarningsMilestone } from "./EarningsMilestone";
import { ConfettiCelebration } from "./ConfettiCelebration";
import {
  AVATAR_OPTIONS,
  countWords,
  calcEarnings,
  formatRands,
  MIN_WORDS,
  submitReview,
} from "@/lib/readingGym";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";
import { toast } from "sonner";


interface ReviewFormProps {
  sessionId: string;
  onSubmitted: () => void;
}


export function ReviewForm({ sessionId, onSubmitted }: ReviewFormProps) {
  const { user, profile } = useAuth();
  const [learnerName, setLearnerName] = useState(profile?.full_name || "");
  const [avatar, setAvatar] = useState("📚");
  const [bookTitle, setBookTitle] = useState("");
  const [bookAuthor, setBookAuthor] = useState("");
  const [starRating, setStarRating] = useState(3);
  const [reviewText, setReviewText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);


  const wordCount = useMemo(() => countWords(reviewText), [reviewText]);
  const canSubmit = wordCount >= MIN_WORDS && bookTitle.trim() && learnerName.trim();


  const handleSubmit = async () => {
    if (!user || !canSubmit) return;
    setSubmitting(true);
    try {
      const wc = countWords(reviewText);
      const earnings = calcEarnings(wc);
      await submitReview({
        session_id: sessionId,
        learner_id: user.id,
        learner_name: learnerName.trim(),
        avatar_emoji: avatar,
        book_title: bookTitle.trim(),
        book_author: bookAuthor.trim(),
        star_rating: starRating,
        review_text: reviewText.trim(),
        word_count: wc,
        earnings_cents: earnings,
      });
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);
      toast.success(`Review submitted! You earned ${formatRands(earnings)} 🎉`);
      setBookTitle("");
      setBookAuthor("");
      setStarRating(3);
      setReviewText("");
      onSubmitted();
    } catch (err: any) {
      toast.error(err.message || "Failed to submit review");
    } finally {
      setSubmitting(false);
    }
  };


  return (
    <div className="space-y-5">
      <ConfettiCelebration trigger={showConfetti} />


      {/* Learner Identity */}
      <Card>
        <CardContent className="pt-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Your Name</label>
            <Input
              value={learnerName}
              onChange={(e) => setLearnerName(e.target.value)}
              placeholder="Enter your name"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Pick your avatar</label>
            <div className="flex flex-wrap gap-2">
              {AVATAR_OPTIONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setAvatar(emoji)}
                  className={cn(
                    "w-12 h-12 text-2xl rounded-full flex items-center justify-center transition-all border-2",
                    avatar === emoji
                      ? "border-primary bg-primary/10 scale-110"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>


      {/* Book Details */}
      <Card>
        <CardContent className="pt-5 space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Book Title *</label>
            <Input
              value={bookTitle}
              onChange={(e) => setBookTitle(e.target.value)}
              placeholder="What book did you read?"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-1 block">Author (optional)</label>
            <Input
              value={bookAuthor}
              onChange={(e) => setBookAuthor(e.target.value)}
              placeholder="Who wrote it?"
            />
          </div>
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">Your Rating</label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <button key={i} type="button" onClick={() => setStarRating(i)}>
                  <Star
                    className={cn(
                      "w-8 h-8 transition-colors",
                      i <= starRating
                        ? "fill-warning text-warning"
                        : "text-muted-foreground/30"
                    )}
                  />
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>


      {/* Review Writing */}
      <Card>
        <CardContent className="pt-5 space-y-4">
          <Textarea
            value={reviewText}
            onChange={(e) => setReviewText(e.target.value)}
            placeholder="Write your honest review here. Every word earns you R0.02 — so write as much as you like!"
            className="min-h-[150px] text-base"
          />
          <WordCounter wordCount={wordCount} />
          <EarningsMilestone wordCount={wordCount} />
        </CardContent>
      </Card>


      {/* Submit */}
      <Button
        onClick={handleSubmit}
        disabled={!canSubmit || submitting}
        variant="orange"
        size="lg"
        className="w-full text-lg"
      >
        {submitting ? "Submitting…" : "Submit my review & earn 💰"}
      </Button>
    </div>
  );
}
