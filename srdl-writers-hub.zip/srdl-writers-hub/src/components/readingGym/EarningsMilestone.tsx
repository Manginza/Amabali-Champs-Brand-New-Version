import { getMilestone } from "@/lib/readingGym";
import { motion, AnimatePresence } from "framer-motion";


interface EarningsMilestoneProps {
  wordCount: number;
}


export function EarningsMilestone({ wordCount }: EarningsMilestoneProps) {
  const milestone = getMilestone(wordCount);


  return (
    <AnimatePresence mode="wait">
      {milestone && (
        <motion.div
          key={milestone.words}
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10 }}
          className="bg-success/15 border border-success/30 rounded-xl px-4 py-3 text-center font-display font-semibold text-success"
        >
          {milestone.message}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
