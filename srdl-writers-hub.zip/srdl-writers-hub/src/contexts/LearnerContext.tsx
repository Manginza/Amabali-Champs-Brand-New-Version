const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}


import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { SchoolId, GradeValue } from "@/data/schools";


interface LearnerProfile {
  name: string;
  schoolId: SchoolId | null;
  grade: GradeValue | null;
  readingStreak: number;
  storiesRead: number;
  storiesWritten: number;
  badges: string[];
  totalPoints: number;
}


interface LearnerContextType {
  learner: LearnerProfile;
  updateLearner: (updates: Partial<LearnerProfile>) => void;
  addBadge: (badge: string) => void;
  incrementStreak: () => void;
  addPoints: (points: number) => void;
}


const defaultLearner: LearnerProfile = {
  name: "",
  schoolId: null,
  grade: null,
  readingStreak: 0,
  storiesRead: 0,
  storiesWritten: 0,
  badges: ["First Login"],
  totalPoints: 0,
};


const LearnerContext = createContext<LearnerContextType | undefined>(undefined);


export function LearnerProvider({ children }: { children: ReactNode }) {
  const [learner, setLearner] = useState<LearnerProfile>(() => {
    const saved = localStorage.getItem("learnerProfile");
    return saved ? JSON.parse(saved) : defaultLearner;
  });


  useEffect(() => {
    localStorage.setItem("learnerProfile", JSON.stringify(learner));
  }, [learner]);


  const updateLearner = (updates: Partial<LearnerProfile>) => {
    setLearner((prev) => ({ ...prev, ...updates }));
  };


  const addBadge = (badge: string) => {
    if (!learner.badges.includes(badge)) {
      setLearner((prev) => ({
        ...prev,
        badges: [...prev.badges, badge],
      }));
    }
  };


  const incrementStreak = () => {
    setLearner((prev) => ({
      ...prev,
      readingStreak: prev.readingStreak + 1,
    }));
  };


  const addPoints = (points: number) => {
    setLearner((prev) => ({
      ...prev,
      totalPoints: prev.totalPoints + points,
    }));
  };


  return (
    <LearnerContext.Provider
      value={{ learner, updateLearner, addBadge, incrementStreak, addPoints }}
    >
      {children}
    </LearnerContext.Provider>
  );
}


export function useLearner() {
