learner_id: string;
  learner_name: string;
  avatar_emoji: string;
  review_count: number;
  total_words: number;
  total_earnings: number;
  earliest_submission: string;
}


export function buildLeaderboard(reviews: any[]): LeaderboardEntry[] {
  const map = new Map<string, LeaderboardEntry>();
  for (const r of reviews) {
    const existing = map.get(r.learner_id);
    if (existing) {
      existing.review_count++;
      existing.total_words += r.word_count;
      existing.total_earnings += r.earnings_cents;
      if (r.submitted_at < existing.earliest_submission) {
        existing.earliest_submission = r.submitted_at;
      }
    } else {
      map.set(r.learner_id, {
        learner_id: r.learner_id,
        learner_name: r.learner_name,
        avatar_emoji: r.avatar_emoji || "📚",
        review_count: 1,
        total_words: r.word_count,
        total_earnings: r.earnings_cents,
        earliest_submission: r.submitted_at,
      });
    }
  }
  return Array.from(map.values()).sort((a, b) => {
    if (b.total_earnings !== a.total_earnings) return b.total_earnings - a.total_earnings;
    return a.earliest_submission.localeCompare(b.earliest_submission);
  });
}


// Session management for anonymous users
const SESSION_KEY = 'srdl_session_id';
const REVIEWS_KEY = 'srdl_submitted_reviews';


export function getSessionId(): string {
  let sessionId = localStorage.getItem(SESSION_KEY);
  if (!sessionId) {
    sessionId = crypto.randomUUID();
    localStorage.setItem(SESSION_KEY, sessionId);
  }
  return sessionId;
}


interface SubmittedReview {
  bookTitle: string;
  studentName: string;
  timestamp: number;
}


export function getSubmittedReviews(): SubmittedReview[] {
  const data = localStorage.getItem(REVIEWS_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}


export function hasSubmittedReview(bookTitle: string, studentName: string): boolean {
  const reviews = getSubmittedReviews();
  const normalizedBook = bookTitle.toLowerCase().trim();
  const normalizedName = studentName.toLowerCase().trim();
  
  return reviews.some(
    (r) => r.bookTitle.toLowerCase().trim() === normalizedBook && 
           r.studentName.toLowerCase().trim() === normalizedName
  );
}


export function recordSubmittedReview(bookTitle: string, studentName: string): void {
  const reviews = getSubmittedReviews();
  reviews.push({
    bookTitle: bookTitle.trim(),
    studentName: studentName.trim(),
    timestamp: Date.now(),
  });
  localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
}


/**
 * Convert a string to a URL-friendly slug
 * @param text - The text to convert
 * @returns A lowercase, hyphenated string safe for URLs
 */
export const slugify = (text: string): string => {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/[\s_-]+/g, '-') // Replace spaces and underscores with hyphens
    .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
};


/**
 * Generate a review URL path
 * @param bookName - The book name
 * @param studentName - The student/reviewer name
 * @returns SEO-friendly URL path
 */
export const generateReviewPath = (bookName: string, studentName: string): string => {
  const bookSlug = slugify(bookName);
  const studentSlug = slugify(studentName);
  return `/reviews/${bookSlug}/${studentSlug}`;
};


import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
