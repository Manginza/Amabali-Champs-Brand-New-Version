const context = useContext(LearnerContext);
  if (context === undefined) {
    throw new Error("useLearner must be used within a LearnerProvider");
  }
  return context;
}
export const schools = [
  { id: "entshona", name: "Entshona Primary School" },
  { id: "mzamomhle", name: "Mzamomhle Primary School" },
  { id: "sizakuyenza", name: "Sizakuyenza Primary School" },
  { id: "bhongolethu", name: "Bhongolethu Primary School" },
  { id: "sikelela", name: "Sikelela Primary School" },
  { id: "imbasa", name: "Imbasa Primary School" },
  { id: "sigcawu", name: "Sigcawu Primary School" },
  { id: "kuyakhanya", name: "Kuyakhanya Primary School" },
  { id: "mkhanyiseli", name: "Mkhanyiseli Primary School" },
] as const;


export const grades = [
  { value: "3", label: "Grade 3" },
  { value: "4", label: "Grade 4" },
  { value: "5", label: "Grade 5" },
  { value: "6", label: "Grade 6" },
  { value: "7", label: "Grade 7" },
] as const;


export const languages = [
  { value: "English", label: "English" },
  { value: "Xhosa", label: "Xhosa" },
  { value: "Zulu", label: "Zulu" },
  { value: "Tswana", label: "Tswana" },
  { value: "Sotho", label: "Sotho" },
  { value: "Pedi", label: "Pedi" },
  { value: "Venda", label: "Venda" },
  { value: "Tsonga", label: "Tsonga" },
  { value: "Ndebele", label: "Ndebele" },
  { value: "Afrikaans", label: "Afrikaans" },
] as const;


export type SchoolId = typeof schools[number]["id"];
export type GradeValue = typeof grades[number]["value"];
export type Language = typeof languages[number]["value"];


import * as React from "react";


const MOBILE_BREAKPOINT = 768;


export function useIsMobile() {
