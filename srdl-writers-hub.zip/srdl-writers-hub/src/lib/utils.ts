export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}


import { useState, useEffect } from "react";
