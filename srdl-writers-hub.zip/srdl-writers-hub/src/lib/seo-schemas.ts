bookName: string;
  author?: string;
  reviewerName: string;
  rating: number;
  reviewContent: string;
  datePublished: string;
  schoolName: string;
  language?: string;
}) => ({
  "@context": "https://schema.org",
  "@type": "Review",
  "@id": `#review-${review.bookName.toLowerCase().replace(/\s+/g, '-')}`,
  itemReviewed: {
    "@type": "Book",
    name: review.bookName,
    author: review.author ? { "@type": "Person", name: review.author } : undefined,
    inLanguage: review.language || "en",
  },
  reviewRating: {
    "@type": "Rating",
    ratingValue: review.rating,
    bestRating: 5,
    worstRating: 1,
  },
  author: {
    "@type": "Person",
    name: review.reviewerName,
  },
  reviewBody: review.reviewContent,
  datePublished: review.datePublished,
  publisher: {
    "@type": "EducationalOrganization",
    name: review.schoolName,
    address: {
      "@type": "PostalAddress",
      addressCountry: "ZA",
    },
  },
  inLanguage: review.language || "en",
});


// Helper to generate aggregate rating schema
export const generateAggregateRatingSchema = (book: {
  bookName: string;
  author?: string;
  avgRating: number;
  reviewCount: number;
}) => ({
  "@context": "https://schema.org",
  "@type": "Book",
  name: book.bookName,
  author: book.author ? { "@type": "Person", name: book.author } : undefined,
  aggregateRating: {
    "@type": "AggregateRating",
    ratingValue: book.avgRating,
    bestRating: 5,
    worstRating: 1,
    ratingCount: book.reviewCount,
  },
});


// Helper to generate WebSite schema for the main site
export const generateWebsiteSchema = () => ({
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "SRDL Writers Hub",
  url: typeof window !== "undefined" ? window.location.origin : "",
  description: "Student book reviews platform where learners earn rewards for sharing authentic book feedback",
  potentialAction: {
    "@type": "SearchAction",
    target: {
      "@type": "EntryPoint",
      urlTemplate: typeof window !== "undefined" ? `${window.location.origin}/reviews-feed?search={search_term_string}` : "",
    },
    "query-input": "required name=search_term_string",
  },
  publisher: {
    "@type": "EducationalOrganization",
    name: "SRDL Writers Hub",
    address: {
      "@type": "PostalAddress",
      addressCountry: "ZA",
    },
  },
});


// Helper to generate ItemList schema for reviews feed
export const generateReviewsListSchema = (reviews: Array<{
  bookName: string;
  reviewerName: string;
  rating: number;
  reviewUrl: string;
}>) => ({
  "@context": "https://schema.org",
  "@type": "ItemList",
  name: "Student Book Reviews",
  description: "Collection of authentic book reviews written by students",
  numberOfItems: reviews.length,
  itemListElement: reviews.slice(0, 10).map((review, index) => ({
    "@type": "ListItem",
    position: index + 1,
    item: {
      "@type": "Review",
      name: `${review.bookName} Review by ${review.reviewerName}`,
      url: review.reviewUrl,
      reviewRating: {
        "@type": "Rating",
        ratingValue: review.rating,
        bestRating: 5,
      },
    },
  })),
});
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";


interface StarRatingProps {
  rating: number;
  maxRating?: number;
  onRate?: (rating: number) => void;
  size?: "sm" | "md" | "lg";
  interactive?: boolean;
}


const sizeClasses = {
  sm: "w-4 h-4",
  md: "w-6 h-6",
  lg: "w-8 h-8",
};


export function StarRating({
