import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchSessionReviews, buildLeaderboard, LeaderboardEntry } from "@/lib/readingGym";


export function useLeaderboard(sessionId: string | null) {
  const [reviews, setReviews] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);


  const refresh = useCallback(async () => {
    if (!sessionId) return;
    const data = await fetchSessionReviews(sessionId);
    setReviews(data);
    setLeaderboard(buildLeaderboard(data));
  }, [sessionId]);


  useEffect(() => {
    refresh();
  }, [refresh]);


  // Realtime subscription
  useEffect(() => {
    if (!sessionId) return;


    const channel = supabase
      .channel(`reading-gym-${sessionId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "reading_gym_reviews",
          filter: `session_id=eq.${sessionId}`,
        },
        () => {
          refresh();
        }
      )
      .subscribe();


    return () => {
      supabase.removeChannel(channel);
    };
  }, [sessionId, refresh]);


  return { reviews, leaderboard, refresh };
}
import { useState, useEffect } from "react";
import { fetchActiveSession } from "@/lib/readingGym";
